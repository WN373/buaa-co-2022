/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/MyFileAtD/CO2022/buaa-co-2022/P6/P6extends/DM.v";
static int ng1[] = {0, 0};
static int ng2[] = {4096, 0};
static int ng3[] = {1, 0};
static unsigned int ng4[] = {15U, 0U};
static unsigned int ng5[] = {12U, 0U};
static unsigned int ng6[] = {0U, 0U};
static unsigned int ng7[] = {3U, 0U};
static unsigned int ng8[] = {8U, 0U};
static unsigned int ng9[] = {4U, 0U};
static unsigned int ng10[] = {2U, 0U};
static unsigned int ng11[] = {1U, 0U};
static int ng12[] = {31, 0};
static int ng13[] = {16, 0};
static int ng14[] = {15, 0};
static int ng15[] = {24, 0};
static int ng16[] = {23, 0};
static int ng17[] = {8, 0};
static int ng18[] = {7, 0};
static const char *ng19 = "@%h: *%h <= %h";



static int sp_RESET(char *t1, char *t2)
{
    char t7[8];
    char t16[8];
    char t17[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned int t28;
    int t29;
    char *t30;
    unsigned int t31;
    int t32;
    int t33;
    unsigned int t34;
    unsigned int t35;
    int t36;
    int t37;

LAB0:    t0 = 1;
    xsi_set_current_line(28, ng0);

LAB2:    xsi_set_current_line(29, ng0);
    xsi_set_current_line(29, ng0);
    t3 = ((char*)((ng1)));
    t4 = (t1 + 2280);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);

LAB3:    t3 = (t1 + 2280);
    t4 = (t3 + 36U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng2)));
    memset(t7, 0, 8);
    xsi_vlog_signed_less(t7, 32, t5, 32, t6, 32);
    t8 = (t7 + 4);
    t9 = *((unsigned int *)t8);
    t10 = (~(t9));
    t11 = *((unsigned int *)t7);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB4;

LAB5:    t0 = 0;

LAB1:    return t0;
LAB4:    xsi_set_current_line(29, ng0);

LAB6:    xsi_set_current_line(30, ng0);
    t14 = ((char*)((ng1)));
    t15 = (t1 + 2004);
    t18 = (t1 + 2004);
    t19 = (t18 + 44U);
    t20 = *((char **)t19);
    t21 = (t1 + 2004);
    t22 = (t21 + 40U);
    t23 = *((char **)t22);
    t24 = (t1 + 2280);
    t25 = (t24 + 36U);
    t26 = *((char **)t25);
    xsi_vlog_generic_convert_array_indices(t16, t17, t20, t23, 2, 1, t26, 32, 1);
    t27 = (t16 + 4);
    t28 = *((unsigned int *)t27);
    t29 = (!(t28));
    t30 = (t17 + 4);
    t31 = *((unsigned int *)t30);
    t32 = (!(t31));
    t33 = (t29 && t32);
    if (t33 == 1)
        goto LAB7;

LAB8:    xsi_set_current_line(29, ng0);
    t3 = (t1 + 2280);
    t4 = (t3 + 36U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng3)));
    memset(t7, 0, 8);
    xsi_vlog_signed_add(t7, 32, t5, 32, t6, 32);
    t8 = (t1 + 2280);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 32);
    goto LAB3;

LAB7:    t34 = *((unsigned int *)t16);
    t35 = *((unsigned int *)t17);
    t36 = (t34 - t35);
    t37 = (t36 + 1);
    xsi_vlogvar_assign_value(t15, t14, 0, *((unsigned int *)t17), t37);
    goto LAB8;

}

static void Cont_15_0(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;

LAB0:    t1 = (t0 + 2804U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1316U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t3 + 4);
    t5 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 2);
    *((unsigned int *)t3) = t7;
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 2);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t10 & 4095U);
    t11 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t11 & 4095U);
    t12 = (t0 + 3644);
    t13 = (t12 + 32U);
    t14 = *((char **)t13);
    t15 = (t14 + 40U);
    t16 = *((char **)t15);
    memset(t16, 0, 8);
    t17 = 4095U;
    t18 = t17;
    t19 = (t3 + 4);
    t20 = *((unsigned int *)t3);
    t17 = (t17 & t20);
    t21 = *((unsigned int *)t19);
    t18 = (t18 & t21);
    t22 = (t16 + 4);
    t23 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t23 | t17);
    t24 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t24 | t18);
    xsi_driver_vfirst_trans(t12, 0, 11);
    t25 = (t0 + 3576);
    *((int *)t25) = 1;

LAB1:    return;
}

static void Cont_16_1(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    t1 = (t0 + 2948U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(16, ng0);
    t2 = (t0 + 2004);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t6 = (t0 + 2004);
    t7 = (t6 + 44U);
    t8 = *((char **)t7);
    t9 = (t0 + 2004);
    t10 = (t9 + 40U);
    t11 = *((char **)t10);
    t12 = (t0 + 1776U);
    t13 = *((char **)t12);
    xsi_vlog_generic_get_array_select_value(t5, 32, t4, t8, t11, 2, 1, t13, 12, 2);
    t12 = (t0 + 3680);
    t14 = (t12 + 32U);
    t15 = *((char **)t14);
    t16 = (t15 + 40U);
    t17 = *((char **)t16);
    memcpy(t17, t5, 8);
    xsi_driver_vfirst_trans(t12, 0, 31);
    t18 = (t0 + 3584);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_17_2(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t39[8];
    char t40[8];
    char t42[8];
    char t69[8];
    char t70[8];
    char t85[8];
    char t86[8];
    char t89[8];
    char t116[8];
    char t117[8];
    char t132[8];
    char t133[8];
    char t136[8];
    char t163[8];
    char t164[8];
    char t179[8];
    char t180[8];
    char t183[8];
    char t210[8];
    char t211[8];
    char t226[8];
    char t227[8];
    char t230[8];
    char t257[8];
    char t258[8];
    char t273[8];
    char t274[8];
    char t277[8];
    char t304[8];
    char t305[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t41;
    char *t43;
    char *t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    char *t64;
    char *t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    char *t71;
    char *t72;
    char *t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    char *t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    char *t87;
    char *t88;
    char *t90;
    char *t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    char *t104;
    char *t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    char *t111;
    char *t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    char *t118;
    char *t119;
    char *t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    char *t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    unsigned int t131;
    char *t134;
    char *t135;
    char *t137;
    char *t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    char *t151;
    char *t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    unsigned int t157;
    char *t158;
    char *t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    char *t165;
    char *t166;
    char *t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    char *t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    char *t181;
    char *t182;
    char *t184;
    char *t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    char *t198;
    char *t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    char *t205;
    char *t206;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    char *t212;
    char *t213;
    char *t214;
    unsigned int t215;
    unsigned int t216;
    unsigned int t217;
    unsigned int t218;
    unsigned int t219;
    unsigned int t220;
    char *t221;
    unsigned int t222;
    unsigned int t223;
    unsigned int t224;
    unsigned int t225;
    char *t228;
    char *t229;
    char *t231;
    char *t232;
    unsigned int t233;
    unsigned int t234;
    unsigned int t235;
    unsigned int t236;
    unsigned int t237;
    unsigned int t238;
    unsigned int t239;
    unsigned int t240;
    unsigned int t241;
    unsigned int t242;
    unsigned int t243;
    unsigned int t244;
    char *t245;
    char *t246;
    unsigned int t247;
    unsigned int t248;
    unsigned int t249;
    unsigned int t250;
    unsigned int t251;
    char *t252;
    char *t253;
    unsigned int t254;
    unsigned int t255;
    unsigned int t256;
    char *t259;
    char *t260;
    char *t261;
    unsigned int t262;
    unsigned int t263;
    unsigned int t264;
    unsigned int t265;
    unsigned int t266;
    unsigned int t267;
    char *t268;
    unsigned int t269;
    unsigned int t270;
    unsigned int t271;
    unsigned int t272;
    char *t275;
    char *t276;
    char *t278;
    char *t279;
    unsigned int t280;
    unsigned int t281;
    unsigned int t282;
    unsigned int t283;
    unsigned int t284;
    unsigned int t285;
    unsigned int t286;
    unsigned int t287;
    unsigned int t288;
    unsigned int t289;
    unsigned int t290;
    unsigned int t291;
    char *t292;
    char *t293;
    unsigned int t294;
    unsigned int t295;
    unsigned int t296;
    unsigned int t297;
    unsigned int t298;
    char *t299;
    char *t300;
    unsigned int t301;
    unsigned int t302;
    unsigned int t303;
    char *t306;
    char *t307;
    char *t308;
    unsigned int t309;
    unsigned int t310;
    unsigned int t311;
    unsigned int t312;
    unsigned int t313;
    unsigned int t314;
    char *t315;
    unsigned int t316;
    unsigned int t317;
    unsigned int t318;
    unsigned int t319;
    char *t320;
    char *t321;
    char *t322;
    char *t323;
    char *t324;
    char *t325;
    char *t326;

LAB0:    t1 = (t0 + 3092U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(17, ng0);
    t2 = (t0 + 1224U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng4)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t2 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t2);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t4, 0, 8);
    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t22) != 0)
        goto LAB10;

LAB11:    t29 = (t4 + 4);
    t30 = *((unsigned int *)t4);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB12;

LAB13:    t35 = *((unsigned int *)t4);
    t36 = (~(t35));
    t37 = *((unsigned int *)t29);
    t38 = (t36 || t37);
    if (t38 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t29) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t39, 8);

LAB20:    t321 = (t0 + 3716);
    t322 = (t321 + 32U);
    t323 = *((char **)t322);
    t324 = (t323 + 40U);
    t325 = *((char **)t324);
    memcpy(t325, t3, 8);
    xsi_driver_vfirst_trans(t321, 0, 31);
    t326 = (t0 + 3592);
    *((int *)t326) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    t28 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB11;

LAB12:    t33 = (t0 + 1684U);
    t34 = *((char **)t33);
    goto LAB13;

LAB14:    t33 = (t0 + 1224U);
    t41 = *((char **)t33);
    t33 = ((char*)((ng5)));
    memset(t42, 0, 8);
    t43 = (t41 + 4);
    t44 = (t33 + 4);
    t45 = *((unsigned int *)t41);
    t46 = *((unsigned int *)t33);
    t47 = (t45 ^ t46);
    t48 = *((unsigned int *)t43);
    t49 = *((unsigned int *)t44);
    t50 = (t48 ^ t49);
    t51 = (t47 | t50);
    t52 = *((unsigned int *)t43);
    t53 = *((unsigned int *)t44);
    t54 = (t52 | t53);
    t55 = (~(t54));
    t56 = (t51 & t55);
    if (t56 != 0)
        goto LAB24;

LAB21:    if (t54 != 0)
        goto LAB23;

LAB22:    *((unsigned int *)t42) = 1;

LAB24:    memset(t40, 0, 8);
    t58 = (t42 + 4);
    t59 = *((unsigned int *)t58);
    t60 = (~(t59));
    t61 = *((unsigned int *)t42);
    t62 = (t61 & t60);
    t63 = (t62 & 1U);
    if (t63 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t58) != 0)
        goto LAB27;

LAB28:    t65 = (t40 + 4);
    t66 = *((unsigned int *)t40);
    t67 = *((unsigned int *)t65);
    t68 = (t66 || t67);
    if (t68 > 0)
        goto LAB29;

LAB30:    t81 = *((unsigned int *)t40);
    t82 = (~(t81));
    t83 = *((unsigned int *)t65);
    t84 = (t82 || t83);
    if (t84 > 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t65) > 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t40) > 0)
        goto LAB35;

LAB36:    memcpy(t39, t85, 8);

LAB37:    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 32, t34, 32, t39, 32);
    goto LAB20;

LAB18:    memcpy(t3, t34, 8);
    goto LAB20;

LAB23:    t57 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t57) = 1;
    goto LAB24;

LAB25:    *((unsigned int *)t40) = 1;
    goto LAB28;

LAB27:    t64 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t64) = 1;
    goto LAB28;

LAB29:    t71 = (t0 + 1684U);
    t72 = *((char **)t71);
    memset(t70, 0, 8);
    t71 = (t70 + 4);
    t73 = (t72 + 4);
    t74 = *((unsigned int *)t72);
    t75 = (t74 >> 16);
    *((unsigned int *)t70) = t75;
    t76 = *((unsigned int *)t73);
    t77 = (t76 >> 16);
    *((unsigned int *)t71) = t77;
    t78 = *((unsigned int *)t70);
    *((unsigned int *)t70) = (t78 & 65535U);
    t79 = *((unsigned int *)t71);
    *((unsigned int *)t71) = (t79 & 65535U);
    t80 = ((char*)((ng6)));
    xsi_vlogtype_concat(t69, 32, 32, 2U, t80, 16, t70, 16);
    goto LAB30;

LAB31:    t87 = (t0 + 1224U);
    t88 = *((char **)t87);
    t87 = ((char*)((ng7)));
    memset(t89, 0, 8);
    t90 = (t88 + 4);
    t91 = (t87 + 4);
    t92 = *((unsigned int *)t88);
    t93 = *((unsigned int *)t87);
    t94 = (t92 ^ t93);
    t95 = *((unsigned int *)t90);
    t96 = *((unsigned int *)t91);
    t97 = (t95 ^ t96);
    t98 = (t94 | t97);
    t99 = *((unsigned int *)t90);
    t100 = *((unsigned int *)t91);
    t101 = (t99 | t100);
    t102 = (~(t101));
    t103 = (t98 & t102);
    if (t103 != 0)
        goto LAB41;

LAB38:    if (t101 != 0)
        goto LAB40;

LAB39:    *((unsigned int *)t89) = 1;

LAB41:    memset(t86, 0, 8);
    t105 = (t89 + 4);
    t106 = *((unsigned int *)t105);
    t107 = (~(t106));
    t108 = *((unsigned int *)t89);
    t109 = (t108 & t107);
    t110 = (t109 & 1U);
    if (t110 != 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t105) != 0)
        goto LAB44;

LAB45:    t112 = (t86 + 4);
    t113 = *((unsigned int *)t86);
    t114 = *((unsigned int *)t112);
    t115 = (t113 || t114);
    if (t115 > 0)
        goto LAB46;

LAB47:    t128 = *((unsigned int *)t86);
    t129 = (~(t128));
    t130 = *((unsigned int *)t112);
    t131 = (t129 || t130);
    if (t131 > 0)
        goto LAB48;

LAB49:    if (*((unsigned int *)t112) > 0)
        goto LAB50;

LAB51:    if (*((unsigned int *)t86) > 0)
        goto LAB52;

LAB53:    memcpy(t85, t132, 8);

LAB54:    goto LAB32;

LAB33:    xsi_vlog_unsigned_bit_combine(t39, 32, t69, 32, t85, 32);
    goto LAB37;

LAB35:    memcpy(t39, t69, 8);
    goto LAB37;

LAB40:    t104 = (t89 + 4);
    *((unsigned int *)t89) = 1;
    *((unsigned int *)t104) = 1;
    goto LAB41;

LAB42:    *((unsigned int *)t86) = 1;
    goto LAB45;

LAB44:    t111 = (t86 + 4);
    *((unsigned int *)t86) = 1;
    *((unsigned int *)t111) = 1;
    goto LAB45;

LAB46:    t118 = (t0 + 1684U);
    t119 = *((char **)t118);
    memset(t117, 0, 8);
    t118 = (t117 + 4);
    t120 = (t119 + 4);
    t121 = *((unsigned int *)t119);
    t122 = (t121 >> 0);
    *((unsigned int *)t117) = t122;
    t123 = *((unsigned int *)t120);
    t124 = (t123 >> 0);
    *((unsigned int *)t118) = t124;
    t125 = *((unsigned int *)t117);
    *((unsigned int *)t117) = (t125 & 65535U);
    t126 = *((unsigned int *)t118);
    *((unsigned int *)t118) = (t126 & 65535U);
    t127 = ((char*)((ng6)));
    xsi_vlogtype_concat(t116, 32, 32, 2U, t127, 16, t117, 16);
    goto LAB47;

LAB48:    t134 = (t0 + 1224U);
    t135 = *((char **)t134);
    t134 = ((char*)((ng8)));
    memset(t136, 0, 8);
    t137 = (t135 + 4);
    t138 = (t134 + 4);
    t139 = *((unsigned int *)t135);
    t140 = *((unsigned int *)t134);
    t141 = (t139 ^ t140);
    t142 = *((unsigned int *)t137);
    t143 = *((unsigned int *)t138);
    t144 = (t142 ^ t143);
    t145 = (t141 | t144);
    t146 = *((unsigned int *)t137);
    t147 = *((unsigned int *)t138);
    t148 = (t146 | t147);
    t149 = (~(t148));
    t150 = (t145 & t149);
    if (t150 != 0)
        goto LAB58;

LAB55:    if (t148 != 0)
        goto LAB57;

LAB56:    *((unsigned int *)t136) = 1;

LAB58:    memset(t133, 0, 8);
    t152 = (t136 + 4);
    t153 = *((unsigned int *)t152);
    t154 = (~(t153));
    t155 = *((unsigned int *)t136);
    t156 = (t155 & t154);
    t157 = (t156 & 1U);
    if (t157 != 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t152) != 0)
        goto LAB61;

LAB62:    t159 = (t133 + 4);
    t160 = *((unsigned int *)t133);
    t161 = *((unsigned int *)t159);
    t162 = (t160 || t161);
    if (t162 > 0)
        goto LAB63;

LAB64:    t175 = *((unsigned int *)t133);
    t176 = (~(t175));
    t177 = *((unsigned int *)t159);
    t178 = (t176 || t177);
    if (t178 > 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t159) > 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t133) > 0)
        goto LAB69;

LAB70:    memcpy(t132, t179, 8);

LAB71:    goto LAB49;

LAB50:    xsi_vlog_unsigned_bit_combine(t85, 32, t116, 32, t132, 32);
    goto LAB54;

LAB52:    memcpy(t85, t116, 8);
    goto LAB54;

LAB57:    t151 = (t136 + 4);
    *((unsigned int *)t136) = 1;
    *((unsigned int *)t151) = 1;
    goto LAB58;

LAB59:    *((unsigned int *)t133) = 1;
    goto LAB62;

LAB61:    t158 = (t133 + 4);
    *((unsigned int *)t133) = 1;
    *((unsigned int *)t158) = 1;
    goto LAB62;

LAB63:    t165 = (t0 + 1684U);
    t166 = *((char **)t165);
    memset(t164, 0, 8);
    t165 = (t164 + 4);
    t167 = (t166 + 4);
    t168 = *((unsigned int *)t166);
    t169 = (t168 >> 24);
    *((unsigned int *)t164) = t169;
    t170 = *((unsigned int *)t167);
    t171 = (t170 >> 24);
    *((unsigned int *)t165) = t171;
    t172 = *((unsigned int *)t164);
    *((unsigned int *)t164) = (t172 & 255U);
    t173 = *((unsigned int *)t165);
    *((unsigned int *)t165) = (t173 & 255U);
    t174 = ((char*)((ng6)));
    xsi_vlogtype_concat(t163, 32, 32, 2U, t174, 24, t164, 8);
    goto LAB64;

LAB65:    t181 = (t0 + 1224U);
    t182 = *((char **)t181);
    t181 = ((char*)((ng9)));
    memset(t183, 0, 8);
    t184 = (t182 + 4);
    t185 = (t181 + 4);
    t186 = *((unsigned int *)t182);
    t187 = *((unsigned int *)t181);
    t188 = (t186 ^ t187);
    t189 = *((unsigned int *)t184);
    t190 = *((unsigned int *)t185);
    t191 = (t189 ^ t190);
    t192 = (t188 | t191);
    t193 = *((unsigned int *)t184);
    t194 = *((unsigned int *)t185);
    t195 = (t193 | t194);
    t196 = (~(t195));
    t197 = (t192 & t196);
    if (t197 != 0)
        goto LAB75;

LAB72:    if (t195 != 0)
        goto LAB74;

LAB73:    *((unsigned int *)t183) = 1;

LAB75:    memset(t180, 0, 8);
    t199 = (t183 + 4);
    t200 = *((unsigned int *)t199);
    t201 = (~(t200));
    t202 = *((unsigned int *)t183);
    t203 = (t202 & t201);
    t204 = (t203 & 1U);
    if (t204 != 0)
        goto LAB76;

LAB77:    if (*((unsigned int *)t199) != 0)
        goto LAB78;

LAB79:    t206 = (t180 + 4);
    t207 = *((unsigned int *)t180);
    t208 = *((unsigned int *)t206);
    t209 = (t207 || t208);
    if (t209 > 0)
        goto LAB80;

LAB81:    t222 = *((unsigned int *)t180);
    t223 = (~(t222));
    t224 = *((unsigned int *)t206);
    t225 = (t223 || t224);
    if (t225 > 0)
        goto LAB82;

LAB83:    if (*((unsigned int *)t206) > 0)
        goto LAB84;

LAB85:    if (*((unsigned int *)t180) > 0)
        goto LAB86;

LAB87:    memcpy(t179, t226, 8);

LAB88:    goto LAB66;

LAB67:    xsi_vlog_unsigned_bit_combine(t132, 32, t163, 32, t179, 32);
    goto LAB71;

LAB69:    memcpy(t132, t163, 8);
    goto LAB71;

LAB74:    t198 = (t183 + 4);
    *((unsigned int *)t183) = 1;
    *((unsigned int *)t198) = 1;
    goto LAB75;

LAB76:    *((unsigned int *)t180) = 1;
    goto LAB79;

LAB78:    t205 = (t180 + 4);
    *((unsigned int *)t180) = 1;
    *((unsigned int *)t205) = 1;
    goto LAB79;

LAB80:    t212 = (t0 + 1684U);
    t213 = *((char **)t212);
    memset(t211, 0, 8);
    t212 = (t211 + 4);
    t214 = (t213 + 4);
    t215 = *((unsigned int *)t213);
    t216 = (t215 >> 16);
    *((unsigned int *)t211) = t216;
    t217 = *((unsigned int *)t214);
    t218 = (t217 >> 16);
    *((unsigned int *)t212) = t218;
    t219 = *((unsigned int *)t211);
    *((unsigned int *)t211) = (t219 & 255U);
    t220 = *((unsigned int *)t212);
    *((unsigned int *)t212) = (t220 & 255U);
    t221 = ((char*)((ng6)));
    xsi_vlogtype_concat(t210, 32, 32, 2U, t221, 24, t211, 8);
    goto LAB81;

LAB82:    t228 = (t0 + 1224U);
    t229 = *((char **)t228);
    t228 = ((char*)((ng10)));
    memset(t230, 0, 8);
    t231 = (t229 + 4);
    t232 = (t228 + 4);
    t233 = *((unsigned int *)t229);
    t234 = *((unsigned int *)t228);
    t235 = (t233 ^ t234);
    t236 = *((unsigned int *)t231);
    t237 = *((unsigned int *)t232);
    t238 = (t236 ^ t237);
    t239 = (t235 | t238);
    t240 = *((unsigned int *)t231);
    t241 = *((unsigned int *)t232);
    t242 = (t240 | t241);
    t243 = (~(t242));
    t244 = (t239 & t243);
    if (t244 != 0)
        goto LAB92;

LAB89:    if (t242 != 0)
        goto LAB91;

LAB90:    *((unsigned int *)t230) = 1;

LAB92:    memset(t227, 0, 8);
    t246 = (t230 + 4);
    t247 = *((unsigned int *)t246);
    t248 = (~(t247));
    t249 = *((unsigned int *)t230);
    t250 = (t249 & t248);
    t251 = (t250 & 1U);
    if (t251 != 0)
        goto LAB93;

LAB94:    if (*((unsigned int *)t246) != 0)
        goto LAB95;

LAB96:    t253 = (t227 + 4);
    t254 = *((unsigned int *)t227);
    t255 = *((unsigned int *)t253);
    t256 = (t254 || t255);
    if (t256 > 0)
        goto LAB97;

LAB98:    t269 = *((unsigned int *)t227);
    t270 = (~(t269));
    t271 = *((unsigned int *)t253);
    t272 = (t270 || t271);
    if (t272 > 0)
        goto LAB99;

LAB100:    if (*((unsigned int *)t253) > 0)
        goto LAB101;

LAB102:    if (*((unsigned int *)t227) > 0)
        goto LAB103;

LAB104:    memcpy(t226, t273, 8);

LAB105:    goto LAB83;

LAB84:    xsi_vlog_unsigned_bit_combine(t179, 32, t210, 32, t226, 32);
    goto LAB88;

LAB86:    memcpy(t179, t210, 8);
    goto LAB88;

LAB91:    t245 = (t230 + 4);
    *((unsigned int *)t230) = 1;
    *((unsigned int *)t245) = 1;
    goto LAB92;

LAB93:    *((unsigned int *)t227) = 1;
    goto LAB96;

LAB95:    t252 = (t227 + 4);
    *((unsigned int *)t227) = 1;
    *((unsigned int *)t252) = 1;
    goto LAB96;

LAB97:    t259 = (t0 + 1684U);
    t260 = *((char **)t259);
    memset(t258, 0, 8);
    t259 = (t258 + 4);
    t261 = (t260 + 4);
    t262 = *((unsigned int *)t260);
    t263 = (t262 >> 8);
    *((unsigned int *)t258) = t263;
    t264 = *((unsigned int *)t261);
    t265 = (t264 >> 8);
    *((unsigned int *)t259) = t265;
    t266 = *((unsigned int *)t258);
    *((unsigned int *)t258) = (t266 & 255U);
    t267 = *((unsigned int *)t259);
    *((unsigned int *)t259) = (t267 & 255U);
    t268 = ((char*)((ng6)));
    xsi_vlogtype_concat(t257, 32, 32, 2U, t268, 24, t258, 8);
    goto LAB98;

LAB99:    t275 = (t0 + 1224U);
    t276 = *((char **)t275);
    t275 = ((char*)((ng11)));
    memset(t277, 0, 8);
    t278 = (t276 + 4);
    t279 = (t275 + 4);
    t280 = *((unsigned int *)t276);
    t281 = *((unsigned int *)t275);
    t282 = (t280 ^ t281);
    t283 = *((unsigned int *)t278);
    t284 = *((unsigned int *)t279);
    t285 = (t283 ^ t284);
    t286 = (t282 | t285);
    t287 = *((unsigned int *)t278);
    t288 = *((unsigned int *)t279);
    t289 = (t287 | t288);
    t290 = (~(t289));
    t291 = (t286 & t290);
    if (t291 != 0)
        goto LAB109;

LAB106:    if (t289 != 0)
        goto LAB108;

LAB107:    *((unsigned int *)t277) = 1;

LAB109:    memset(t274, 0, 8);
    t293 = (t277 + 4);
    t294 = *((unsigned int *)t293);
    t295 = (~(t294));
    t296 = *((unsigned int *)t277);
    t297 = (t296 & t295);
    t298 = (t297 & 1U);
    if (t298 != 0)
        goto LAB110;

LAB111:    if (*((unsigned int *)t293) != 0)
        goto LAB112;

LAB113:    t300 = (t274 + 4);
    t301 = *((unsigned int *)t274);
    t302 = *((unsigned int *)t300);
    t303 = (t301 || t302);
    if (t303 > 0)
        goto LAB114;

LAB115:    t316 = *((unsigned int *)t274);
    t317 = (~(t316));
    t318 = *((unsigned int *)t300);
    t319 = (t317 || t318);
    if (t319 > 0)
        goto LAB116;

LAB117:    if (*((unsigned int *)t300) > 0)
        goto LAB118;

LAB119:    if (*((unsigned int *)t274) > 0)
        goto LAB120;

LAB121:    memcpy(t273, t320, 8);

LAB122:    goto LAB100;

LAB101:    xsi_vlog_unsigned_bit_combine(t226, 32, t257, 32, t273, 32);
    goto LAB105;

LAB103:    memcpy(t226, t257, 8);
    goto LAB105;

LAB108:    t292 = (t277 + 4);
    *((unsigned int *)t277) = 1;
    *((unsigned int *)t292) = 1;
    goto LAB109;

LAB110:    *((unsigned int *)t274) = 1;
    goto LAB113;

LAB112:    t299 = (t274 + 4);
    *((unsigned int *)t274) = 1;
    *((unsigned int *)t299) = 1;
    goto LAB113;

LAB114:    t306 = (t0 + 1684U);
    t307 = *((char **)t306);
    memset(t305, 0, 8);
    t306 = (t305 + 4);
    t308 = (t307 + 4);
    t309 = *((unsigned int *)t307);
    t310 = (t309 >> 0);
    *((unsigned int *)t305) = t310;
    t311 = *((unsigned int *)t308);
    t312 = (t311 >> 0);
    *((unsigned int *)t306) = t312;
    t313 = *((unsigned int *)t305);
    *((unsigned int *)t305) = (t313 & 255U);
    t314 = *((unsigned int *)t306);
    *((unsigned int *)t306) = (t314 & 255U);
    t315 = ((char*)((ng6)));
    xsi_vlogtype_concat(t304, 32, 32, 2U, t315, 24, t305, 8);
    goto LAB115;

LAB116:    t320 = ((char*)((ng1)));
    goto LAB117;

LAB118:    xsi_vlog_unsigned_bit_combine(t273, 32, t304, 32, t320, 32);
    goto LAB122;

LAB120:    memcpy(t273, t304, 8);
    goto LAB122;

}

static void Initial_35_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    int t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;

LAB0:    t1 = (t0 + 3236U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(35, ng0);

LAB4:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 948U);
    t3 = *((char **)t2);
    t2 = (t0 + 3136);
    t4 = (t0 + 484);
    t5 = xsi_create_subprogram_invocation(t2, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);
    t6 = (t0 + 2188);
    xsi_vlogvar_assign_value(t6, t3, 0, 0, 1);

LAB7:    t7 = (t0 + 3188);
    t8 = *((char **)t7);
    t9 = (t8 + 44U);
    t10 = *((char **)t9);
    t11 = (t10 + 148U);
    t12 = *((char **)t11);
    t13 = (t12 + 0U);
    t14 = *((char **)t13);
    t15 = ((int  (*)(char *, char *))t14)(t0, t8);

LAB9:    if (t15 != 0)
        goto LAB10;

LAB5:    t8 = (t0 + 484);
    xsi_vlog_subprogram_popinvocation(t8);

LAB6:    t16 = (t0 + 3188);
    t17 = *((char **)t16);
    t16 = (t0 + 484);
    t18 = (t0 + 3136);
    t19 = 0;
    xsi_delete_subprogram_invocation(t16, t17, t0, t18, t19);

LAB1:    return;
LAB8:;
LAB10:    t7 = (t0 + 3236U);
    *((char **)t7) = &&LAB7;
    goto LAB1;

}

static void Always_40_4(char *t0)
{
    char t29[8];
    char t30[8];
    char t40[8];
    char t41[8];
    char t42[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    int t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t31;
    int t32;
    unsigned int t33;
    int t34;
    int t35;
    unsigned int t36;
    unsigned int t37;
    int t38;
    int t39;
    int t43;
    int t44;
    int t45;
    int t46;
    int t47;
    int t48;
    unsigned int t49;
    int t50;
    int t51;

LAB0:    t1 = (t0 + 3380U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 3600);
    *((int *)t2) = 1;
    t3 = (t0 + 3408);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(40, ng0);

LAB5:    xsi_set_current_line(41, ng0);
    t4 = (t0 + 948U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(44, ng0);
    t2 = (t0 + 1132U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB16;

LAB17:
LAB18:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(41, ng0);

LAB9:    xsi_set_current_line(42, ng0);
    t11 = (t0 + 948U);
    t12 = *((char **)t11);
    t11 = (t0 + 3280);
    t13 = (t0 + 484);
    t14 = xsi_create_subprogram_invocation(t11, 0, t0, t13, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t13, t14);
    t15 = (t0 + 2188);
    xsi_vlogvar_assign_value(t15, t12, 0, 0, 1);

LAB12:    t16 = (t0 + 3332);
    t17 = *((char **)t16);
    t18 = (t17 + 44U);
    t19 = *((char **)t18);
    t20 = (t19 + 148U);
    t21 = *((char **)t20);
    t22 = (t21 + 0U);
    t23 = *((char **)t22);
    t24 = ((int  (*)(char *, char *))t23)(t0, t17);

LAB14:    if (t24 != 0)
        goto LAB15;

LAB10:    t17 = (t0 + 484);
    xsi_vlog_subprogram_popinvocation(t17);

LAB11:    t25 = (t0 + 3332);
    t26 = *((char **)t25);
    t25 = (t0 + 484);
    t27 = (t0 + 3280);
    t28 = 0;
    xsi_delete_subprogram_invocation(t25, t26, t0, t27, t28);
    goto LAB8;

LAB13:;
LAB15:    t16 = (t0 + 3380U);
    *((char **)t16) = &&LAB12;
    goto LAB1;

LAB16:    xsi_set_current_line(44, ng0);

LAB19:    xsi_set_current_line(45, ng0);
    t4 = (t0 + 1224U);
    t5 = *((char **)t4);

LAB20:    t4 = ((char*)((ng4)));
    t24 = xsi_vlog_unsigned_case_compare(t5, 4, t4, 4);
    if (t24 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng5)));
    t24 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t24 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng7)));
    t24 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t24 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng8)));
    t24 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t24 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng9)));
    t24 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t24 == 1)
        goto LAB29;

LAB30:    t2 = ((char*)((ng10)));
    t24 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t24 == 1)
        goto LAB31;

LAB32:    t2 = ((char*)((ng11)));
    t24 = xsi_vlog_unsigned_case_compare(t5, 4, t2, 4);
    if (t24 == 1)
        goto LAB33;

LAB34:
LAB36:
LAB35:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 2004);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t11 = (t0 + 2004);
    t12 = (t11 + 44U);
    t13 = *((char **)t12);
    t14 = (t0 + 2004);
    t15 = (t14 + 40U);
    t16 = *((char **)t15);
    t17 = (t0 + 1776U);
    t18 = *((char **)t17);
    xsi_vlog_generic_get_array_select_value(t29, 32, t4, t13, t16, 2, 1, t18, 12, 2);
    t17 = (t0 + 2004);
    t19 = (t0 + 2004);
    t20 = (t19 + 44U);
    t21 = *((char **)t20);
    t22 = (t0 + 2004);
    t23 = (t22 + 40U);
    t25 = *((char **)t23);
    t26 = (t0 + 1776U);
    t27 = *((char **)t26);
    xsi_vlog_generic_convert_array_indices(t30, t40, t21, t25, 2, 1, t27, 12, 2);
    t26 = (t30 + 4);
    t6 = *((unsigned int *)t26);
    t24 = (!(t6));
    t28 = (t40 + 4);
    t7 = *((unsigned int *)t28);
    t32 = (!(t7));
    t34 = (t24 && t32);
    if (t34 == 1)
        goto LAB52;

LAB53:
LAB37:    xsi_set_current_line(55, ng0);
    t2 = (t0 + 1500U);
    t3 = *((char **)t2);
    t2 = (t0 + 1316U);
    t4 = *((char **)t2);
    t2 = (t0 + 1408U);
    t11 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng19, 4, t0, (char)118, t3, 32, (char)118, t4, 32, (char)118, t11, 32);
    goto LAB18;

LAB21:    xsi_set_current_line(46, ng0);
    t11 = (t0 + 1408U);
    t12 = *((char **)t11);
    t11 = (t0 + 2004);
    t13 = (t0 + 2004);
    t14 = (t13 + 44U);
    t15 = *((char **)t14);
    t16 = (t0 + 2004);
    t17 = (t16 + 40U);
    t18 = *((char **)t17);
    t19 = (t0 + 1776U);
    t20 = *((char **)t19);
    xsi_vlog_generic_convert_array_indices(t29, t30, t15, t18, 2, 1, t20, 12, 2);
    t19 = (t29 + 4);
    t31 = *((unsigned int *)t19);
    t32 = (!(t31));
    t21 = (t30 + 4);
    t33 = *((unsigned int *)t21);
    t34 = (!(t33));
    t35 = (t32 && t34);
    if (t35 == 1)
        goto LAB38;

LAB39:    goto LAB37;

LAB23:    xsi_set_current_line(47, ng0);
    t3 = (t0 + 1408U);
    t4 = *((char **)t3);
    t3 = (t0 + 2004);
    t11 = (t0 + 2004);
    t12 = (t11 + 44U);
    t13 = *((char **)t12);
    t14 = (t0 + 2004);
    t15 = (t14 + 40U);
    t16 = *((char **)t15);
    t17 = (t0 + 1776U);
    t18 = *((char **)t17);
    xsi_vlog_generic_convert_array_indices(t29, t30, t13, t16, 2, 1, t18, 12, 2);
    t17 = (t0 + 2004);
    t19 = (t17 + 44U);
    t20 = *((char **)t19);
    t21 = ((char*)((ng12)));
    t22 = ((char*)((ng13)));
    xsi_vlog_convert_partindices(t40, t41, t42, ((int*)(t20)), 2, t21, 32, 1, t22, 32, 1);
    t23 = (t29 + 4);
    t6 = *((unsigned int *)t23);
    t32 = (!(t6));
    t25 = (t30 + 4);
    t7 = *((unsigned int *)t25);
    t34 = (!(t7));
    t35 = (t32 && t34);
    t26 = (t40 + 4);
    t8 = *((unsigned int *)t26);
    t38 = (!(t8));
    t39 = (t35 && t38);
    t27 = (t41 + 4);
    t9 = *((unsigned int *)t27);
    t43 = (!(t9));
    t44 = (t39 && t43);
    t28 = (t42 + 4);
    t10 = *((unsigned int *)t28);
    t45 = (!(t10));
    t46 = (t44 && t45);
    if (t46 == 1)
        goto LAB40;

LAB41:    goto LAB37;

LAB25:    xsi_set_current_line(48, ng0);
    t3 = (t0 + 1408U);
    t4 = *((char **)t3);
    t3 = (t0 + 2004);
    t11 = (t0 + 2004);
    t12 = (t11 + 44U);
    t13 = *((char **)t12);
    t14 = (t0 + 2004);
    t15 = (t14 + 40U);
    t16 = *((char **)t15);
    t17 = (t0 + 1776U);
    t18 = *((char **)t17);
    xsi_vlog_generic_convert_array_indices(t29, t30, t13, t16, 2, 1, t18, 12, 2);
    t17 = (t0 + 2004);
    t19 = (t17 + 44U);
    t20 = *((char **)t19);
    t21 = ((char*)((ng14)));
    t22 = ((char*)((ng1)));
    xsi_vlog_convert_partindices(t40, t41, t42, ((int*)(t20)), 2, t21, 32, 1, t22, 32, 1);
    t23 = (t29 + 4);
    t6 = *((unsigned int *)t23);
    t32 = (!(t6));
    t25 = (t30 + 4);
    t7 = *((unsigned int *)t25);
    t34 = (!(t7));
    t35 = (t32 && t34);
    t26 = (t40 + 4);
    t8 = *((unsigned int *)t26);
    t38 = (!(t8));
    t39 = (t35 && t38);
    t27 = (t41 + 4);
    t9 = *((unsigned int *)t27);
    t43 = (!(t9));
    t44 = (t39 && t43);
    t28 = (t42 + 4);
    t10 = *((unsigned int *)t28);
    t45 = (!(t10));
    t46 = (t44 && t45);
    if (t46 == 1)
        goto LAB42;

LAB43:    goto LAB37;

LAB27:    xsi_set_current_line(49, ng0);
    t3 = (t0 + 1408U);
    t4 = *((char **)t3);
    t3 = (t0 + 2004);
    t11 = (t0 + 2004);
    t12 = (t11 + 44U);
    t13 = *((char **)t12);
    t14 = (t0 + 2004);
    t15 = (t14 + 40U);
    t16 = *((char **)t15);
    t17 = (t0 + 1776U);
    t18 = *((char **)t17);
    xsi_vlog_generic_convert_array_indices(t29, t30, t13, t16, 2, 1, t18, 12, 2);
    t17 = (t0 + 2004);
    t19 = (t17 + 44U);
    t20 = *((char **)t19);
    t21 = ((char*)((ng12)));
    t22 = ((char*)((ng15)));
    xsi_vlog_convert_partindices(t40, t41, t42, ((int*)(t20)), 2, t21, 32, 1, t22, 32, 1);
    t23 = (t29 + 4);
    t6 = *((unsigned int *)t23);
    t32 = (!(t6));
    t25 = (t30 + 4);
    t7 = *((unsigned int *)t25);
    t34 = (!(t7));
    t35 = (t32 && t34);
    t26 = (t40 + 4);
    t8 = *((unsigned int *)t26);
    t38 = (!(t8));
    t39 = (t35 && t38);
    t27 = (t41 + 4);
    t9 = *((unsigned int *)t27);
    t43 = (!(t9));
    t44 = (t39 && t43);
    t28 = (t42 + 4);
    t10 = *((unsigned int *)t28);
    t45 = (!(t10));
    t46 = (t44 && t45);
    if (t46 == 1)
        goto LAB44;

LAB45:    goto LAB37;

LAB29:    xsi_set_current_line(50, ng0);
    t3 = (t0 + 1408U);
    t4 = *((char **)t3);
    t3 = (t0 + 2004);
    t11 = (t0 + 2004);
    t12 = (t11 + 44U);
    t13 = *((char **)t12);
    t14 = (t0 + 2004);
    t15 = (t14 + 40U);
    t16 = *((char **)t15);
    t17 = (t0 + 1776U);
    t18 = *((char **)t17);
    xsi_vlog_generic_convert_array_indices(t29, t30, t13, t16, 2, 1, t18, 12, 2);
    t17 = (t0 + 2004);
    t19 = (t17 + 44U);
    t20 = *((char **)t19);
    t21 = ((char*)((ng16)));
    t22 = ((char*)((ng13)));
    xsi_vlog_convert_partindices(t40, t41, t42, ((int*)(t20)), 2, t21, 32, 1, t22, 32, 1);
    t23 = (t29 + 4);
    t6 = *((unsigned int *)t23);
    t32 = (!(t6));
    t25 = (t30 + 4);
    t7 = *((unsigned int *)t25);
    t34 = (!(t7));
    t35 = (t32 && t34);
    t26 = (t40 + 4);
    t8 = *((unsigned int *)t26);
    t38 = (!(t8));
    t39 = (t35 && t38);
    t27 = (t41 + 4);
    t9 = *((unsigned int *)t27);
    t43 = (!(t9));
    t44 = (t39 && t43);
    t28 = (t42 + 4);
    t10 = *((unsigned int *)t28);
    t45 = (!(t10));
    t46 = (t44 && t45);
    if (t46 == 1)
        goto LAB46;

LAB47:    goto LAB37;

LAB31:    xsi_set_current_line(51, ng0);
    t3 = (t0 + 1408U);
    t4 = *((char **)t3);
    t3 = (t0 + 2004);
    t11 = (t0 + 2004);
    t12 = (t11 + 44U);
    t13 = *((char **)t12);
    t14 = (t0 + 2004);
    t15 = (t14 + 40U);
    t16 = *((char **)t15);
    t17 = (t0 + 1776U);
    t18 = *((char **)t17);
    xsi_vlog_generic_convert_array_indices(t29, t30, t13, t16, 2, 1, t18, 12, 2);
    t17 = (t0 + 2004);
    t19 = (t17 + 44U);
    t20 = *((char **)t19);
    t21 = ((char*)((ng14)));
    t22 = ((char*)((ng17)));
    xsi_vlog_convert_partindices(t40, t41, t42, ((int*)(t20)), 2, t21, 32, 1, t22, 32, 1);
    t23 = (t29 + 4);
    t6 = *((unsigned int *)t23);
    t32 = (!(t6));
    t25 = (t30 + 4);
    t7 = *((unsigned int *)t25);
    t34 = (!(t7));
    t35 = (t32 && t34);
    t26 = (t40 + 4);
    t8 = *((unsigned int *)t26);
    t38 = (!(t8));
    t39 = (t35 && t38);
    t27 = (t41 + 4);
    t9 = *((unsigned int *)t27);
    t43 = (!(t9));
    t44 = (t39 && t43);
    t28 = (t42 + 4);
    t10 = *((unsigned int *)t28);
    t45 = (!(t10));
    t46 = (t44 && t45);
    if (t46 == 1)
        goto LAB48;

LAB49:    goto LAB37;

LAB33:    xsi_set_current_line(52, ng0);
    t3 = (t0 + 1408U);
    t4 = *((char **)t3);
    t3 = (t0 + 2004);
    t11 = (t0 + 2004);
    t12 = (t11 + 44U);
    t13 = *((char **)t12);
    t14 = (t0 + 2004);
    t15 = (t14 + 40U);
    t16 = *((char **)t15);
    t17 = (t0 + 1776U);
    t18 = *((char **)t17);
    xsi_vlog_generic_convert_array_indices(t29, t30, t13, t16, 2, 1, t18, 12, 2);
    t17 = (t0 + 2004);
    t19 = (t17 + 44U);
    t20 = *((char **)t19);
    t21 = ((char*)((ng18)));
    t22 = ((char*)((ng1)));
    xsi_vlog_convert_partindices(t40, t41, t42, ((int*)(t20)), 2, t21, 32, 1, t22, 32, 1);
    t23 = (t29 + 4);
    t6 = *((unsigned int *)t23);
    t32 = (!(t6));
    t25 = (t30 + 4);
    t7 = *((unsigned int *)t25);
    t34 = (!(t7));
    t35 = (t32 && t34);
    t26 = (t40 + 4);
    t8 = *((unsigned int *)t26);
    t38 = (!(t8));
    t39 = (t35 && t38);
    t27 = (t41 + 4);
    t9 = *((unsigned int *)t27);
    t43 = (!(t9));
    t44 = (t39 && t43);
    t28 = (t42 + 4);
    t10 = *((unsigned int *)t28);
    t45 = (!(t10));
    t46 = (t44 && t45);
    if (t46 == 1)
        goto LAB50;

LAB51:    goto LAB37;

LAB38:    t36 = *((unsigned int *)t29);
    t37 = *((unsigned int *)t30);
    t38 = (t36 - t37);
    t39 = (t38 + 1);
    xsi_vlogvar_assign_value(t11, t12, 0, *((unsigned int *)t30), t39);
    goto LAB39;

LAB40:    t31 = *((unsigned int *)t42);
    t47 = (t31 + 0);
    t33 = *((unsigned int *)t30);
    t36 = *((unsigned int *)t41);
    t48 = (t33 + t36);
    t37 = *((unsigned int *)t40);
    t49 = *((unsigned int *)t41);
    t50 = (t37 - t49);
    t51 = (t50 + 1);
    xsi_vlogvar_assign_value(t3, t4, t47, t48, t51);
    goto LAB41;

LAB42:    t31 = *((unsigned int *)t42);
    t47 = (t31 + 0);
    t33 = *((unsigned int *)t30);
    t36 = *((unsigned int *)t41);
    t48 = (t33 + t36);
    t37 = *((unsigned int *)t40);
    t49 = *((unsigned int *)t41);
    t50 = (t37 - t49);
    t51 = (t50 + 1);
    xsi_vlogvar_assign_value(t3, t4, t47, t48, t51);
    goto LAB43;

LAB44:    t31 = *((unsigned int *)t42);
    t47 = (t31 + 0);
    t33 = *((unsigned int *)t30);
    t36 = *((unsigned int *)t41);
    t48 = (t33 + t36);
    t37 = *((unsigned int *)t40);
    t49 = *((unsigned int *)t41);
    t50 = (t37 - t49);
    t51 = (t50 + 1);
    xsi_vlogvar_assign_value(t3, t4, t47, t48, t51);
    goto LAB45;

LAB46:    t31 = *((unsigned int *)t42);
    t47 = (t31 + 0);
    t33 = *((unsigned int *)t30);
    t36 = *((unsigned int *)t41);
    t48 = (t33 + t36);
    t37 = *((unsigned int *)t40);
    t49 = *((unsigned int *)t41);
    t50 = (t37 - t49);
    t51 = (t50 + 1);
    xsi_vlogvar_assign_value(t3, t4, t47, t48, t51);
    goto LAB47;

LAB48:    t31 = *((unsigned int *)t42);
    t47 = (t31 + 0);
    t33 = *((unsigned int *)t30);
    t36 = *((unsigned int *)t41);
    t48 = (t33 + t36);
    t37 = *((unsigned int *)t40);
    t49 = *((unsigned int *)t41);
    t50 = (t37 - t49);
    t51 = (t50 + 1);
    xsi_vlogvar_assign_value(t3, t4, t47, t48, t51);
    goto LAB49;

LAB50:    t31 = *((unsigned int *)t42);
    t47 = (t31 + 0);
    t33 = *((unsigned int *)t30);
    t36 = *((unsigned int *)t41);
    t48 = (t33 + t36);
    t37 = *((unsigned int *)t40);
    t49 = *((unsigned int *)t41);
    t50 = (t37 - t49);
    t51 = (t50 + 1);
    xsi_vlogvar_assign_value(t3, t4, t47, t48, t51);
    goto LAB51;

LAB52:    t8 = *((unsigned int *)t30);
    t9 = *((unsigned int *)t40);
    t35 = (t8 - t9);
    t38 = (t35 + 1);
    xsi_vlogvar_assign_value(t17, t29, 0, *((unsigned int *)t40), t38);
    goto LAB53;

}


extern void work_m_00000000003198362941_2924402094_init()
{
	static char *pe[] = {(void *)Cont_15_0,(void *)Cont_16_1,(void *)Cont_17_2,(void *)Initial_35_3,(void *)Always_40_4};
	static char *se[] = {(void *)sp_RESET};
	xsi_register_didat("work_m_00000000003198362941_2924402094", "isim/mips_tb6_isim_beh.exe.sim/work/m_00000000003198362941_2924402094.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
