/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/media/shared/CO2022/P6oncourse/T1L4/Memory.v";
static unsigned int ng1[] = {29U, 0U};
static int ng2[] = {0, 0};
static int ng3[] = {1, 0};
static int ng4[] = {2, 0};
static unsigned int ng5[] = {31U, 0U};
static int ng6[] = {3, 0};
static int ng7[] = {8, 0};
static int ng8[] = {4, 0};
static int ng9[] = {5, 0};
static unsigned int ng10[] = {0U, 0U};
static int ng11[] = {16, 0};
static unsigned int ng12[] = {2U, 0U};
static int ng13[] = {24, 0};
static unsigned int ng14[] = {1U, 0U};
static unsigned int ng15[] = {3U, 0U};
static unsigned int ng16[] = {15U, 0U};
static unsigned int ng17[] = {12U, 0U};
static unsigned int ng18[] = {4U, 0U};
static unsigned int ng19[] = {8U, 0U};



static void Cont_12_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 6360U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(12, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 8856);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t8 = (t0 + 8664);
    *((int *)t8) = 1;

LAB1:    return;
}

static void NetDecl_15_1(char *t0)
{
    char t3[8];
    char t4[8];
    char t21[8];
    char *t1;
    char *t2;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t22;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;

LAB0:    t1 = (t0 + 6608U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 3448U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t2) != 0)
        goto LAB6;

LAB7:    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t12);
    t15 = (t13 || t14);
    if (t15 > 0)
        goto LAB8;

LAB9:    t17 = *((unsigned int *)t4);
    t18 = (~(t17));
    t19 = *((unsigned int *)t12);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t12) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t21, 8);

LAB16:    t31 = (t0 + 8920);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    t34 = (t33 + 56U);
    t35 = *((char **)t34);
    memset(t35, 0, 8);
    t36 = 31U;
    t37 = t36;
    t38 = (t3 + 4);
    t39 = *((unsigned int *)t3);
    t36 = (t36 & t39);
    t40 = *((unsigned int *)t38);
    t37 = (t37 & t40);
    t41 = (t35 + 4);
    t42 = *((unsigned int *)t35);
    *((unsigned int *)t35) = (t42 | t36);
    t43 = *((unsigned int *)t41);
    *((unsigned int *)t41) = (t43 | t37);
    xsi_driver_vfirst_trans(t31, 0, 4U);
    t44 = (t0 + 8680);
    *((int *)t44) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t11 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB7;

LAB8:    t16 = ((char*)((ng1)));
    goto LAB9;

LAB10:    t22 = (t0 + 1368U);
    t23 = *((char **)t22);
    memset(t21, 0, 8);
    t22 = (t21 + 4);
    t24 = (t23 + 4);
    t25 = *((unsigned int *)t23);
    t26 = (t25 >> 16);
    *((unsigned int *)t21) = t26;
    t27 = *((unsigned int *)t24);
    t28 = (t27 >> 16);
    *((unsigned int *)t22) = t28;
    t29 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t29 & 31U);
    t30 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t30 & 31U);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 5, t16, 5, t21, 5);
    goto LAB16;

LAB14:    memcpy(t3, t16, 8);
    goto LAB16;

}

static void NetDecl_15_2(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;

LAB0:    t1 = (t0 + 6856U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(16, ng0);
    t2 = (t0 + 1368U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t3 + 4);
    t5 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 21);
    *((unsigned int *)t3) = t7;
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 21);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t10 & 31U);
    t11 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t11 & 31U);
    t12 = (t0 + 8984);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memset(t16, 0, 8);
    t17 = 31U;
    t18 = t17;
    t19 = (t3 + 4);
    t20 = *((unsigned int *)t3);
    t17 = (t17 & t20);
    t21 = *((unsigned int *)t19);
    t18 = (t18 & t21);
    t22 = (t16 + 4);
    t23 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t23 | t17);
    t24 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t24 | t18);
    xsi_driver_vfirst_trans(t12, 0, 4U);
    t25 = (t0 + 8696);
    *((int *)t25) = 1;

LAB1:    return;
}

static void NetDecl_15_3(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;

LAB0:    t1 = (t0 + 7104U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(17, ng0);
    t2 = (t0 + 1368U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t3 + 4);
    t5 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 11);
    *((unsigned int *)t3) = t7;
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 11);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t10 & 31U);
    t11 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t11 & 31U);
    t12 = (t0 + 9048);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memset(t16, 0, 8);
    t17 = 31U;
    t18 = t17;
    t19 = (t3 + 4);
    t20 = *((unsigned int *)t3);
    t17 = (t17 & t20);
    t21 = *((unsigned int *)t19);
    t18 = (t18 & t21);
    t22 = (t16 + 4);
    t23 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t23 | t17);
    t24 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t24 | t18);
    xsi_driver_vfirst_trans(t12, 0, 4U);
    t25 = (t0 + 8712);
    *((int *)t25) = 1;

LAB1:    return;
}

static void Cont_21_4(char *t0)
{
    char t3[8];
    char t4[8];
    char t5[8];
    char t29[8];
    char t30[8];
    char t33[8];
    char t62[8];
    char t67[8];
    char t68[8];
    char t70[8];
    char t99[8];
    char t104[8];
    char t105[8];
    char t107[8];
    char t139[8];
    char t140[8];
    char t143[8];
    char *t1;
    char *t2;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t31;
    char *t32;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    char *t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    char *t60;
    char *t61;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    char *t69;
    char *t71;
    char *t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    char *t85;
    char *t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    char *t92;
    char *t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    char *t97;
    char *t98;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    char *t106;
    char *t108;
    char *t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    char *t122;
    char *t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;
    char *t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    char *t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    char *t141;
    char *t142;
    char *t144;
    char *t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    unsigned int t157;
    char *t158;
    char *t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    char *t165;
    char *t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    char *t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    char *t175;
    char *t176;
    char *t177;
    char *t178;
    char *t179;
    char *t180;
    unsigned int t181;
    unsigned int t182;
    char *t183;
    unsigned int t184;
    unsigned int t185;
    char *t186;
    unsigned int t187;
    unsigned int t188;
    char *t189;

LAB0:    t1 = (t0 + 7352U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(21, ng0);
    t2 = (t0 + 4088U);
    t6 = *((char **)t2);
    memset(t5, 0, 8);
    t2 = (t6 + 4);
    t7 = *((unsigned int *)t2);
    t8 = (~(t7));
    t9 = *((unsigned int *)t6);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB7;

LAB5:    if (*((unsigned int *)t2) == 0)
        goto LAB4;

LAB6:    t12 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t12) = 1;

LAB7:    memset(t4, 0, 8);
    t13 = (t5 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t5);
    t17 = (t16 & t15);
    t18 = (t17 & 1U);
    if (t18 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t13) != 0)
        goto LAB10;

LAB11:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t4);
    t22 = *((unsigned int *)t20);
    t23 = (t21 || t22);
    if (t23 > 0)
        goto LAB12;

LAB13:    t25 = *((unsigned int *)t4);
    t26 = (~(t25));
    t27 = *((unsigned int *)t20);
    t28 = (t26 || t27);
    if (t28 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t20) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t29, 8);

LAB20:    t176 = (t0 + 9112);
    t177 = (t176 + 56U);
    t178 = *((char **)t177);
    t179 = (t178 + 56U);
    t180 = *((char **)t179);
    memset(t180, 0, 8);
    t181 = 31U;
    t182 = t181;
    t183 = (t3 + 4);
    t184 = *((unsigned int *)t3);
    t181 = (t181 & t184);
    t185 = *((unsigned int *)t183);
    t182 = (t182 & t185);
    t186 = (t180 + 4);
    t187 = *((unsigned int *)t180);
    *((unsigned int *)t180) = (t187 | t181);
    t188 = *((unsigned int *)t186);
    *((unsigned int *)t186) = (t188 | t182);
    xsi_driver_vfirst_trans(t176, 0, 4);
    t189 = (t0 + 8728);
    *((int *)t189) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t5) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB11;

LAB12:    t24 = ((char*)((ng2)));
    goto LAB13;

LAB14:    t31 = (t0 + 4568U);
    t32 = *((char **)t31);
    t31 = ((char*)((ng2)));
    memset(t33, 0, 8);
    t34 = (t32 + 4);
    t35 = (t31 + 4);
    t36 = *((unsigned int *)t32);
    t37 = *((unsigned int *)t31);
    t38 = (t36 ^ t37);
    t39 = *((unsigned int *)t34);
    t40 = *((unsigned int *)t35);
    t41 = (t39 ^ t40);
    t42 = (t38 | t41);
    t43 = *((unsigned int *)t34);
    t44 = *((unsigned int *)t35);
    t45 = (t43 | t44);
    t46 = (~(t45));
    t47 = (t42 & t46);
    if (t47 != 0)
        goto LAB24;

LAB21:    if (t45 != 0)
        goto LAB23;

LAB22:    *((unsigned int *)t33) = 1;

LAB24:    memset(t30, 0, 8);
    t49 = (t33 + 4);
    t50 = *((unsigned int *)t49);
    t51 = (~(t50));
    t52 = *((unsigned int *)t33);
    t53 = (t52 & t51);
    t54 = (t53 & 1U);
    if (t54 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t49) != 0)
        goto LAB27;

LAB28:    t56 = (t30 + 4);
    t57 = *((unsigned int *)t30);
    t58 = *((unsigned int *)t56);
    t59 = (t57 || t58);
    if (t59 > 0)
        goto LAB29;

LAB30:    t63 = *((unsigned int *)t30);
    t64 = (~(t63));
    t65 = *((unsigned int *)t56);
    t66 = (t64 || t65);
    if (t66 > 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t56) > 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t30) > 0)
        goto LAB35;

LAB36:    memcpy(t29, t67, 8);

LAB37:    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 32, t24, 32, t29, 32);
    goto LAB20;

LAB18:    memcpy(t3, t24, 8);
    goto LAB20;

LAB23:    t48 = (t33 + 4);
    *((unsigned int *)t33) = 1;
    *((unsigned int *)t48) = 1;
    goto LAB24;

LAB25:    *((unsigned int *)t30) = 1;
    goto LAB28;

LAB27:    t55 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t55) = 1;
    goto LAB28;

LAB29:    t60 = (t0 + 3608U);
    t61 = *((char **)t60);
    memcpy(t62, t61, 8);
    goto LAB30;

LAB31:    t60 = (t0 + 4568U);
    t69 = *((char **)t60);
    t60 = ((char*)((ng3)));
    memset(t70, 0, 8);
    t71 = (t69 + 4);
    t72 = (t60 + 4);
    t73 = *((unsigned int *)t69);
    t74 = *((unsigned int *)t60);
    t75 = (t73 ^ t74);
    t76 = *((unsigned int *)t71);
    t77 = *((unsigned int *)t72);
    t78 = (t76 ^ t77);
    t79 = (t75 | t78);
    t80 = *((unsigned int *)t71);
    t81 = *((unsigned int *)t72);
    t82 = (t80 | t81);
    t83 = (~(t82));
    t84 = (t79 & t83);
    if (t84 != 0)
        goto LAB41;

LAB38:    if (t82 != 0)
        goto LAB40;

LAB39:    *((unsigned int *)t70) = 1;

LAB41:    memset(t68, 0, 8);
    t86 = (t70 + 4);
    t87 = *((unsigned int *)t86);
    t88 = (~(t87));
    t89 = *((unsigned int *)t70);
    t90 = (t89 & t88);
    t91 = (t90 & 1U);
    if (t91 != 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t86) != 0)
        goto LAB44;

LAB45:    t93 = (t68 + 4);
    t94 = *((unsigned int *)t68);
    t95 = *((unsigned int *)t93);
    t96 = (t94 || t95);
    if (t96 > 0)
        goto LAB46;

LAB47:    t100 = *((unsigned int *)t68);
    t101 = (~(t100));
    t102 = *((unsigned int *)t93);
    t103 = (t101 || t102);
    if (t103 > 0)
        goto LAB48;

LAB49:    if (*((unsigned int *)t93) > 0)
        goto LAB50;

LAB51:    if (*((unsigned int *)t68) > 0)
        goto LAB52;

LAB53:    memcpy(t67, t104, 8);

LAB54:    goto LAB32;

LAB33:    xsi_vlog_unsigned_bit_combine(t29, 32, t62, 32, t67, 32);
    goto LAB37;

LAB35:    memcpy(t29, t62, 8);
    goto LAB37;

LAB40:    t85 = (t70 + 4);
    *((unsigned int *)t70) = 1;
    *((unsigned int *)t85) = 1;
    goto LAB41;

LAB42:    *((unsigned int *)t68) = 1;
    goto LAB45;

LAB44:    t92 = (t68 + 4);
    *((unsigned int *)t68) = 1;
    *((unsigned int *)t92) = 1;
    goto LAB45;

LAB46:    t97 = (t0 + 3928U);
    t98 = *((char **)t97);
    memcpy(t99, t98, 8);
    goto LAB47;

LAB48:    t97 = (t0 + 4568U);
    t106 = *((char **)t97);
    t97 = ((char*)((ng4)));
    memset(t107, 0, 8);
    t108 = (t106 + 4);
    t109 = (t97 + 4);
    t110 = *((unsigned int *)t106);
    t111 = *((unsigned int *)t97);
    t112 = (t110 ^ t111);
    t113 = *((unsigned int *)t108);
    t114 = *((unsigned int *)t109);
    t115 = (t113 ^ t114);
    t116 = (t112 | t115);
    t117 = *((unsigned int *)t108);
    t118 = *((unsigned int *)t109);
    t119 = (t117 | t118);
    t120 = (~(t119));
    t121 = (t116 & t120);
    if (t121 != 0)
        goto LAB58;

LAB55:    if (t119 != 0)
        goto LAB57;

LAB56:    *((unsigned int *)t107) = 1;

LAB58:    memset(t105, 0, 8);
    t123 = (t107 + 4);
    t124 = *((unsigned int *)t123);
    t125 = (~(t124));
    t126 = *((unsigned int *)t107);
    t127 = (t126 & t125);
    t128 = (t127 & 1U);
    if (t128 != 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t123) != 0)
        goto LAB61;

LAB62:    t130 = (t105 + 4);
    t131 = *((unsigned int *)t105);
    t132 = *((unsigned int *)t130);
    t133 = (t131 || t132);
    if (t133 > 0)
        goto LAB63;

LAB64:    t135 = *((unsigned int *)t105);
    t136 = (~(t135));
    t137 = *((unsigned int *)t130);
    t138 = (t136 || t137);
    if (t138 > 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t130) > 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t105) > 0)
        goto LAB69;

LAB70:    memcpy(t104, t139, 8);

LAB71:    goto LAB49;

LAB50:    xsi_vlog_unsigned_bit_combine(t67, 32, t99, 32, t104, 32);
    goto LAB54;

LAB52:    memcpy(t67, t99, 8);
    goto LAB54;

LAB57:    t122 = (t107 + 4);
    *((unsigned int *)t107) = 1;
    *((unsigned int *)t122) = 1;
    goto LAB58;

LAB59:    *((unsigned int *)t105) = 1;
    goto LAB62;

LAB61:    t129 = (t105 + 4);
    *((unsigned int *)t105) = 1;
    *((unsigned int *)t129) = 1;
    goto LAB62;

LAB63:    t134 = ((char*)((ng5)));
    goto LAB64;

LAB65:    t141 = (t0 + 4568U);
    t142 = *((char **)t141);
    t141 = ((char*)((ng6)));
    memset(t143, 0, 8);
    t144 = (t142 + 4);
    t145 = (t141 + 4);
    t146 = *((unsigned int *)t142);
    t147 = *((unsigned int *)t141);
    t148 = (t146 ^ t147);
    t149 = *((unsigned int *)t144);
    t150 = *((unsigned int *)t145);
    t151 = (t149 ^ t150);
    t152 = (t148 | t151);
    t153 = *((unsigned int *)t144);
    t154 = *((unsigned int *)t145);
    t155 = (t153 | t154);
    t156 = (~(t155));
    t157 = (t152 & t156);
    if (t157 != 0)
        goto LAB75;

LAB72:    if (t155 != 0)
        goto LAB74;

LAB73:    *((unsigned int *)t143) = 1;

LAB75:    memset(t140, 0, 8);
    t159 = (t143 + 4);
    t160 = *((unsigned int *)t159);
    t161 = (~(t160));
    t162 = *((unsigned int *)t143);
    t163 = (t162 & t161);
    t164 = (t163 & 1U);
    if (t164 != 0)
        goto LAB76;

LAB77:    if (*((unsigned int *)t159) != 0)
        goto LAB78;

LAB79:    t166 = (t140 + 4);
    t167 = *((unsigned int *)t140);
    t168 = *((unsigned int *)t166);
    t169 = (t167 || t168);
    if (t169 > 0)
        goto LAB80;

LAB81:    t171 = *((unsigned int *)t140);
    t172 = (~(t171));
    t173 = *((unsigned int *)t166);
    t174 = (t172 || t173);
    if (t174 > 0)
        goto LAB82;

LAB83:    if (*((unsigned int *)t166) > 0)
        goto LAB84;

LAB85:    if (*((unsigned int *)t140) > 0)
        goto LAB86;

LAB87:    memcpy(t139, t175, 8);

LAB88:    goto LAB66;

LAB67:    xsi_vlog_unsigned_bit_combine(t104, 32, t134, 32, t139, 32);
    goto LAB71;

LAB69:    memcpy(t104, t134, 8);
    goto LAB71;

LAB74:    t158 = (t143 + 4);
    *((unsigned int *)t143) = 1;
    *((unsigned int *)t158) = 1;
    goto LAB75;

LAB76:    *((unsigned int *)t140) = 1;
    goto LAB79;

LAB78:    t165 = (t140 + 4);
    *((unsigned int *)t140) = 1;
    *((unsigned int *)t165) = 1;
    goto LAB79;

LAB80:    t170 = ((char*)((ng1)));
    goto LAB81;

LAB82:    t175 = ((char*)((ng2)));
    goto LAB83;

LAB84:    xsi_vlog_unsigned_bit_combine(t139, 32, t170, 32, t175, 32);
    goto LAB88;

LAB86:    memcpy(t139, t170, 8);
    goto LAB88;

}

static void Cont_27_5(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t39[8];
    char t40[8];
    char t42[8];
    char t74[8];
    char t75[8];
    char t78[8];
    char t111[8];
    char t112[8];
    char t114[8];
    char t143[8];
    char t148[8];
    char t149[8];
    char t152[8];
    char t185[8];
    char t186[8];
    char t188[8];
    char t217[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t41;
    char *t43;
    char *t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    char *t64;
    char *t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    char *t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    char *t76;
    char *t77;
    char *t79;
    char *t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    char *t93;
    char *t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    char *t100;
    char *t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    char *t105;
    char *t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    char *t113;
    char *t115;
    char *t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;
    char *t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    char *t136;
    char *t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    char *t141;
    char *t142;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    char *t150;
    char *t151;
    char *t153;
    char *t154;
    unsigned int t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    char *t167;
    char *t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    char *t174;
    char *t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    char *t179;
    char *t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    char *t187;
    char *t189;
    char *t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    char *t203;
    char *t204;
    unsigned int t205;
    unsigned int t206;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    char *t210;
    char *t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    char *t215;
    char *t216;
    unsigned int t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    char *t222;
    char *t223;
    char *t224;
    char *t225;
    char *t226;
    char *t227;
    char *t228;

LAB0:    t1 = (t0 + 7600U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(27, ng0);
    t2 = (t0 + 4408U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng2)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t2 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t2);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t4, 0, 8);
    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t22) != 0)
        goto LAB10;

LAB11:    t29 = (t4 + 4);
    t30 = *((unsigned int *)t4);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB12;

LAB13:    t35 = *((unsigned int *)t4);
    t36 = (~(t35));
    t37 = *((unsigned int *)t29);
    t38 = (t36 || t37);
    if (t38 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t29) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t39, 8);

LAB20:    t223 = (t0 + 9176);
    t224 = (t223 + 56U);
    t225 = *((char **)t224);
    t226 = (t225 + 56U);
    t227 = *((char **)t226);
    memcpy(t227, t3, 8);
    xsi_driver_vfirst_trans(t223, 0, 31);
    t228 = (t0 + 8744);
    *((int *)t228) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    t28 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB11;

LAB12:    t33 = (t0 + 1688U);
    t34 = *((char **)t33);
    goto LAB13;

LAB14:    t33 = (t0 + 4408U);
    t41 = *((char **)t33);
    t33 = ((char*)((ng3)));
    memset(t42, 0, 8);
    t43 = (t41 + 4);
    t44 = (t33 + 4);
    t45 = *((unsigned int *)t41);
    t46 = *((unsigned int *)t33);
    t47 = (t45 ^ t46);
    t48 = *((unsigned int *)t43);
    t49 = *((unsigned int *)t44);
    t50 = (t48 ^ t49);
    t51 = (t47 | t50);
    t52 = *((unsigned int *)t43);
    t53 = *((unsigned int *)t44);
    t54 = (t52 | t53);
    t55 = (~(t54));
    t56 = (t51 & t55);
    if (t56 != 0)
        goto LAB24;

LAB21:    if (t54 != 0)
        goto LAB23;

LAB22:    *((unsigned int *)t42) = 1;

LAB24:    memset(t40, 0, 8);
    t58 = (t42 + 4);
    t59 = *((unsigned int *)t58);
    t60 = (~(t59));
    t61 = *((unsigned int *)t42);
    t62 = (t61 & t60);
    t63 = (t62 & 1U);
    if (t63 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t58) != 0)
        goto LAB27;

LAB28:    t65 = (t40 + 4);
    t66 = *((unsigned int *)t40);
    t67 = *((unsigned int *)t65);
    t68 = (t66 || t67);
    if (t68 > 0)
        goto LAB29;

LAB30:    t70 = *((unsigned int *)t40);
    t71 = (~(t70));
    t72 = *((unsigned int *)t65);
    t73 = (t71 || t72);
    if (t73 > 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t65) > 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t40) > 0)
        goto LAB35;

LAB36:    memcpy(t39, t74, 8);

LAB37:    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 32, t34, 32, t39, 32);
    goto LAB20;

LAB18:    memcpy(t3, t34, 8);
    goto LAB20;

LAB23:    t57 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t57) = 1;
    goto LAB24;

LAB25:    *((unsigned int *)t40) = 1;
    goto LAB28;

LAB27:    t64 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t64) = 1;
    goto LAB28;

LAB29:    t69 = ((char*)((ng2)));
    goto LAB30;

LAB31:    t76 = (t0 + 4408U);
    t77 = *((char **)t76);
    t76 = ((char*)((ng4)));
    memset(t78, 0, 8);
    t79 = (t77 + 4);
    t80 = (t76 + 4);
    t81 = *((unsigned int *)t77);
    t82 = *((unsigned int *)t76);
    t83 = (t81 ^ t82);
    t84 = *((unsigned int *)t79);
    t85 = *((unsigned int *)t80);
    t86 = (t84 ^ t85);
    t87 = (t83 | t86);
    t88 = *((unsigned int *)t79);
    t89 = *((unsigned int *)t80);
    t90 = (t88 | t89);
    t91 = (~(t90));
    t92 = (t87 & t91);
    if (t92 != 0)
        goto LAB41;

LAB38:    if (t90 != 0)
        goto LAB40;

LAB39:    *((unsigned int *)t78) = 1;

LAB41:    memset(t75, 0, 8);
    t94 = (t78 + 4);
    t95 = *((unsigned int *)t94);
    t96 = (~(t95));
    t97 = *((unsigned int *)t78);
    t98 = (t97 & t96);
    t99 = (t98 & 1U);
    if (t99 != 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t94) != 0)
        goto LAB44;

LAB45:    t101 = (t75 + 4);
    t102 = *((unsigned int *)t75);
    t103 = *((unsigned int *)t101);
    t104 = (t102 || t103);
    if (t104 > 0)
        goto LAB46;

LAB47:    t107 = *((unsigned int *)t75);
    t108 = (~(t107));
    t109 = *((unsigned int *)t101);
    t110 = (t108 || t109);
    if (t110 > 0)
        goto LAB48;

LAB49:    if (*((unsigned int *)t101) > 0)
        goto LAB50;

LAB51:    if (*((unsigned int *)t75) > 0)
        goto LAB52;

LAB53:    memcpy(t74, t111, 8);

LAB54:    goto LAB32;

LAB33:    xsi_vlog_unsigned_bit_combine(t39, 32, t69, 32, t74, 32);
    goto LAB37;

LAB35:    memcpy(t39, t69, 8);
    goto LAB37;

LAB40:    t93 = (t78 + 4);
    *((unsigned int *)t78) = 1;
    *((unsigned int *)t93) = 1;
    goto LAB41;

LAB42:    *((unsigned int *)t75) = 1;
    goto LAB45;

LAB44:    t100 = (t75 + 4);
    *((unsigned int *)t75) = 1;
    *((unsigned int *)t100) = 1;
    goto LAB45;

LAB46:    t105 = (t0 + 2328U);
    t106 = *((char **)t105);
    goto LAB47;

LAB48:    t105 = (t0 + 4408U);
    t113 = *((char **)t105);
    t105 = ((char*)((ng6)));
    memset(t114, 0, 8);
    t115 = (t113 + 4);
    t116 = (t105 + 4);
    t117 = *((unsigned int *)t113);
    t118 = *((unsigned int *)t105);
    t119 = (t117 ^ t118);
    t120 = *((unsigned int *)t115);
    t121 = *((unsigned int *)t116);
    t122 = (t120 ^ t121);
    t123 = (t119 | t122);
    t124 = *((unsigned int *)t115);
    t125 = *((unsigned int *)t116);
    t126 = (t124 | t125);
    t127 = (~(t126));
    t128 = (t123 & t127);
    if (t128 != 0)
        goto LAB58;

LAB55:    if (t126 != 0)
        goto LAB57;

LAB56:    *((unsigned int *)t114) = 1;

LAB58:    memset(t112, 0, 8);
    t130 = (t114 + 4);
    t131 = *((unsigned int *)t130);
    t132 = (~(t131));
    t133 = *((unsigned int *)t114);
    t134 = (t133 & t132);
    t135 = (t134 & 1U);
    if (t135 != 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t130) != 0)
        goto LAB61;

LAB62:    t137 = (t112 + 4);
    t138 = *((unsigned int *)t112);
    t139 = *((unsigned int *)t137);
    t140 = (t138 || t139);
    if (t140 > 0)
        goto LAB63;

LAB64:    t144 = *((unsigned int *)t112);
    t145 = (~(t144));
    t146 = *((unsigned int *)t137);
    t147 = (t145 || t146);
    if (t147 > 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t137) > 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t112) > 0)
        goto LAB69;

LAB70:    memcpy(t111, t148, 8);

LAB71:    goto LAB49;

LAB50:    xsi_vlog_unsigned_bit_combine(t74, 32, t106, 32, t111, 32);
    goto LAB54;

LAB52:    memcpy(t74, t106, 8);
    goto LAB54;

LAB57:    t129 = (t114 + 4);
    *((unsigned int *)t114) = 1;
    *((unsigned int *)t129) = 1;
    goto LAB58;

LAB59:    *((unsigned int *)t112) = 1;
    goto LAB62;

LAB61:    t136 = (t112 + 4);
    *((unsigned int *)t112) = 1;
    *((unsigned int *)t136) = 1;
    goto LAB62;

LAB63:    t141 = (t0 + 1528U);
    t142 = *((char **)t141);
    t141 = ((char*)((ng7)));
    memset(t143, 0, 8);
    xsi_vlog_unsigned_add(t143, 32, t142, 32, t141, 32);
    goto LAB64;

LAB65:    t150 = (t0 + 4408U);
    t151 = *((char **)t150);
    t150 = ((char*)((ng8)));
    memset(t152, 0, 8);
    t153 = (t151 + 4);
    t154 = (t150 + 4);
    t155 = *((unsigned int *)t151);
    t156 = *((unsigned int *)t150);
    t157 = (t155 ^ t156);
    t158 = *((unsigned int *)t153);
    t159 = *((unsigned int *)t154);
    t160 = (t158 ^ t159);
    t161 = (t157 | t160);
    t162 = *((unsigned int *)t153);
    t163 = *((unsigned int *)t154);
    t164 = (t162 | t163);
    t165 = (~(t164));
    t166 = (t161 & t165);
    if (t166 != 0)
        goto LAB75;

LAB72:    if (t164 != 0)
        goto LAB74;

LAB73:    *((unsigned int *)t152) = 1;

LAB75:    memset(t149, 0, 8);
    t168 = (t152 + 4);
    t169 = *((unsigned int *)t168);
    t170 = (~(t169));
    t171 = *((unsigned int *)t152);
    t172 = (t171 & t170);
    t173 = (t172 & 1U);
    if (t173 != 0)
        goto LAB76;

LAB77:    if (*((unsigned int *)t168) != 0)
        goto LAB78;

LAB79:    t175 = (t149 + 4);
    t176 = *((unsigned int *)t149);
    t177 = *((unsigned int *)t175);
    t178 = (t176 || t177);
    if (t178 > 0)
        goto LAB80;

LAB81:    t181 = *((unsigned int *)t149);
    t182 = (~(t181));
    t183 = *((unsigned int *)t175);
    t184 = (t182 || t183);
    if (t184 > 0)
        goto LAB82;

LAB83:    if (*((unsigned int *)t175) > 0)
        goto LAB84;

LAB85:    if (*((unsigned int *)t149) > 0)
        goto LAB86;

LAB87:    memcpy(t148, t185, 8);

LAB88:    goto LAB66;

LAB67:    xsi_vlog_unsigned_bit_combine(t111, 32, t143, 32, t148, 32);
    goto LAB71;

LAB69:    memcpy(t111, t143, 8);
    goto LAB71;

LAB74:    t167 = (t152 + 4);
    *((unsigned int *)t152) = 1;
    *((unsigned int *)t167) = 1;
    goto LAB75;

LAB76:    *((unsigned int *)t149) = 1;
    goto LAB79;

LAB78:    t174 = (t149 + 4);
    *((unsigned int *)t149) = 1;
    *((unsigned int *)t174) = 1;
    goto LAB79;

LAB80:    t179 = (t0 + 1848U);
    t180 = *((char **)t179);
    goto LAB81;

LAB82:    t179 = (t0 + 4408U);
    t187 = *((char **)t179);
    t179 = ((char*)((ng9)));
    memset(t188, 0, 8);
    t189 = (t187 + 4);
    t190 = (t179 + 4);
    t191 = *((unsigned int *)t187);
    t192 = *((unsigned int *)t179);
    t193 = (t191 ^ t192);
    t194 = *((unsigned int *)t189);
    t195 = *((unsigned int *)t190);
    t196 = (t194 ^ t195);
    t197 = (t193 | t196);
    t198 = *((unsigned int *)t189);
    t199 = *((unsigned int *)t190);
    t200 = (t198 | t199);
    t201 = (~(t200));
    t202 = (t197 & t201);
    if (t202 != 0)
        goto LAB92;

LAB89:    if (t200 != 0)
        goto LAB91;

LAB90:    *((unsigned int *)t188) = 1;

LAB92:    memset(t186, 0, 8);
    t204 = (t188 + 4);
    t205 = *((unsigned int *)t204);
    t206 = (~(t205));
    t207 = *((unsigned int *)t188);
    t208 = (t207 & t206);
    t209 = (t208 & 1U);
    if (t209 != 0)
        goto LAB93;

LAB94:    if (*((unsigned int *)t204) != 0)
        goto LAB95;

LAB96:    t211 = (t186 + 4);
    t212 = *((unsigned int *)t186);
    t213 = *((unsigned int *)t211);
    t214 = (t212 || t213);
    if (t214 > 0)
        goto LAB97;

LAB98:    t218 = *((unsigned int *)t186);
    t219 = (~(t218));
    t220 = *((unsigned int *)t211);
    t221 = (t219 || t220);
    if (t221 > 0)
        goto LAB99;

LAB100:    if (*((unsigned int *)t211) > 0)
        goto LAB101;

LAB102:    if (*((unsigned int *)t186) > 0)
        goto LAB103;

LAB104:    memcpy(t185, t222, 8);

LAB105:    goto LAB83;

LAB84:    xsi_vlog_unsigned_bit_combine(t148, 32, t180, 32, t185, 32);
    goto LAB88;

LAB86:    memcpy(t148, t180, 8);
    goto LAB88;

LAB91:    t203 = (t188 + 4);
    *((unsigned int *)t188) = 1;
    *((unsigned int *)t203) = 1;
    goto LAB92;

LAB93:    *((unsigned int *)t186) = 1;
    goto LAB96;

LAB95:    t210 = (t186 + 4);
    *((unsigned int *)t186) = 1;
    *((unsigned int *)t210) = 1;
    goto LAB96;

LAB97:    t215 = (t0 + 2168U);
    t216 = *((char **)t215);
    t215 = ((char*)((ng8)));
    memset(t217, 0, 8);
    xsi_vlog_unsigned_minus(t217, 32, t216, 32, t215, 32);
    goto LAB98;

LAB99:    t222 = ((char*)((ng2)));
    goto LAB100;

LAB101:    xsi_vlog_unsigned_bit_combine(t185, 32, t217, 32, t222, 32);
    goto LAB105;

LAB103:    memcpy(t185, t217, 8);
    goto LAB105;

}

static void Initial_35_6(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(35, ng0);

LAB2:    xsi_set_current_line(36, ng0);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 5128);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);
    xsi_set_current_line(37, ng0);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 5288);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);
    xsi_set_current_line(38, ng0);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 5448);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 4);

LAB1:    return;
}

static void Always_41_7(char *t0)
{
    char t13[8];
    char t37[8];
    char t39[8];
    char t59[8];
    char t60[8];
    char t70[8];
    char t74[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    unsigned int t38;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    char *t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t61;
    char *t62;
    char *t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t71;
    char *t72;
    char *t73;
    char *t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    char *t82;

LAB0:    t1 = (t0 + 8096U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(41, ng0);
    t2 = (t0 + 8760);
    *((int *)t2) = 1;
    t3 = (t0 + 8128);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(41, ng0);

LAB5:    xsi_set_current_line(42, ng0);
    t4 = (t0 + 4248U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(42, ng0);

LAB9:    xsi_set_current_line(43, ng0);
    t11 = (t0 + 4728U);
    t12 = *((char **)t11);
    t11 = ((char*)((ng3)));
    memset(t13, 0, 8);
    t14 = (t12 + 4);
    t15 = (t11 + 4);
    t16 = *((unsigned int *)t12);
    t17 = *((unsigned int *)t11);
    t18 = (t16 ^ t17);
    t19 = *((unsigned int *)t14);
    t20 = *((unsigned int *)t15);
    t21 = (t19 ^ t20);
    t22 = (t18 | t21);
    t23 = *((unsigned int *)t14);
    t24 = *((unsigned int *)t15);
    t25 = (t23 | t24);
    t26 = (~(t25));
    t27 = (t22 & t26);
    if (t27 != 0)
        goto LAB13;

LAB10:    if (t25 != 0)
        goto LAB12;

LAB11:    *((unsigned int *)t13) = 1;

LAB13:    t29 = (t13 + 4);
    t30 = *((unsigned int *)t29);
    t31 = (~(t30));
    t32 = *((unsigned int *)t13);
    t33 = (t32 & t31);
    t34 = (t33 != 0);
    if (t34 > 0)
        goto LAB14;

LAB15:    xsi_set_current_line(45, ng0);
    t2 = (t0 + 4728U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng4)));
    memset(t13, 0, 8);
    t4 = (t3 + 4);
    t5 = (t2 + 4);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t2);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t16 = (t9 ^ t10);
    t17 = (t8 | t16);
    t18 = *((unsigned int *)t4);
    t19 = *((unsigned int *)t5);
    t20 = (t18 | t19);
    t21 = (~(t20));
    t22 = (t17 & t21);
    if (t22 != 0)
        goto LAB21;

LAB18:    if (t20 != 0)
        goto LAB20;

LAB19:    *((unsigned int *)t13) = 1;

LAB21:    t12 = (t13 + 4);
    t23 = *((unsigned int *)t12);
    t24 = (~(t23));
    t25 = *((unsigned int *)t13);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB22;

LAB23:    xsi_set_current_line(51, ng0);
    t2 = (t0 + 4728U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng6)));
    memset(t13, 0, 8);
    t4 = (t3 + 4);
    t5 = (t2 + 4);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t2);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t16 = (t9 ^ t10);
    t17 = (t8 | t16);
    t18 = *((unsigned int *)t4);
    t19 = *((unsigned int *)t5);
    t20 = (t18 | t19);
    t21 = (~(t20));
    t22 = (t17 & t21);
    if (t22 != 0)
        goto LAB45;

LAB42:    if (t20 != 0)
        goto LAB44;

LAB43:    *((unsigned int *)t13) = 1;

LAB45:    t12 = (t13 + 4);
    t23 = *((unsigned int *)t12);
    t24 = (~(t23));
    t25 = *((unsigned int *)t13);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB46;

LAB47:
LAB48:
LAB24:
LAB16:    goto LAB8;

LAB12:    t28 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB13;

LAB14:    xsi_set_current_line(43, ng0);

LAB17:    xsi_set_current_line(44, ng0);
    t35 = (t0 + 2488U);
    t36 = *((char **)t35);
    t35 = (t0 + 5288);
    xsi_vlogvar_assign_value(t35, t36, 0, 0, 32);
    goto LAB16;

LAB20:    t11 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB21;

LAB22:    xsi_set_current_line(45, ng0);

LAB25:    xsi_set_current_line(46, ng0);
    t14 = (t0 + 2648U);
    t15 = *((char **)t14);
    memset(t37, 0, 8);
    t14 = (t37 + 4);
    t28 = (t15 + 4);
    t30 = *((unsigned int *)t15);
    t31 = (t30 >> 0);
    *((unsigned int *)t37) = t31;
    t32 = *((unsigned int *)t28);
    t33 = (t32 >> 0);
    *((unsigned int *)t14) = t33;
    t34 = *((unsigned int *)t37);
    *((unsigned int *)t37) = (t34 & 3U);
    t38 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t38 & 3U);
    t29 = ((char*)((ng10)));
    memset(t39, 0, 8);
    t35 = (t37 + 4);
    t36 = (t29 + 4);
    t40 = *((unsigned int *)t37);
    t41 = *((unsigned int *)t29);
    t42 = (t40 ^ t41);
    t43 = *((unsigned int *)t35);
    t44 = *((unsigned int *)t36);
    t45 = (t43 ^ t44);
    t46 = (t42 | t45);
    t47 = *((unsigned int *)t35);
    t48 = *((unsigned int *)t36);
    t49 = (t47 | t48);
    t50 = (~(t49));
    t51 = (t46 & t50);
    if (t51 != 0)
        goto LAB29;

LAB26:    if (t49 != 0)
        goto LAB28;

LAB27:    *((unsigned int *)t39) = 1;

LAB29:    t53 = (t39 + 4);
    t54 = *((unsigned int *)t53);
    t55 = (~(t54));
    t56 = *((unsigned int *)t39);
    t57 = (t56 & t55);
    t58 = (t57 != 0);
    if (t58 > 0)
        goto LAB30;

LAB31:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 0);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 3U);
    t16 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t16 & 3U);
    t5 = ((char*)((ng12)));
    memset(t37, 0, 8);
    t11 = (t13 + 4);
    t12 = (t5 + 4);
    t17 = *((unsigned int *)t13);
    t18 = *((unsigned int *)t5);
    t19 = (t17 ^ t18);
    t20 = *((unsigned int *)t11);
    t21 = *((unsigned int *)t12);
    t22 = (t20 ^ t21);
    t23 = (t19 | t22);
    t24 = *((unsigned int *)t11);
    t25 = *((unsigned int *)t12);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t30 = (t23 & t27);
    if (t30 != 0)
        goto LAB37;

LAB34:    if (t26 != 0)
        goto LAB36;

LAB35:    *((unsigned int *)t37) = 1;

LAB37:    t15 = (t37 + 4);
    t31 = *((unsigned int *)t15);
    t32 = (~(t31));
    t33 = *((unsigned int *)t37);
    t34 = (t33 & t32);
    t38 = (t34 != 0);
    if (t38 > 0)
        goto LAB38;

LAB39:
LAB40:
LAB32:    goto LAB24;

LAB28:    t52 = (t39 + 4);
    *((unsigned int *)t39) = 1;
    *((unsigned int *)t52) = 1;
    goto LAB29;

LAB30:    xsi_set_current_line(46, ng0);

LAB33:    xsi_set_current_line(47, ng0);
    t61 = (t0 + 2488U);
    t62 = *((char **)t61);
    memset(t60, 0, 8);
    t61 = (t60 + 4);
    t63 = (t62 + 4);
    t64 = *((unsigned int *)t62);
    t65 = (t64 >> 0);
    *((unsigned int *)t60) = t65;
    t66 = *((unsigned int *)t63);
    t67 = (t66 >> 0);
    *((unsigned int *)t61) = t67;
    t68 = *((unsigned int *)t60);
    *((unsigned int *)t60) = (t68 & 65535U);
    t69 = *((unsigned int *)t61);
    *((unsigned int *)t61) = (t69 & 65535U);
    t71 = ((char*)((ng11)));
    t72 = (t0 + 2488U);
    t73 = *((char **)t72);
    memset(t74, 0, 8);
    t72 = (t74 + 4);
    t75 = (t73 + 4);
    t76 = *((unsigned int *)t73);
    t77 = (t76 >> 15);
    t78 = (t77 & 1);
    *((unsigned int *)t74) = t78;
    t79 = *((unsigned int *)t75);
    t80 = (t79 >> 15);
    t81 = (t80 & 1);
    *((unsigned int *)t72) = t81;
    xsi_vlog_mul_concat(t70, 16, 1, t71, 1U, t74, 1);
    xsi_vlogtype_concat(t59, 32, 32, 2U, t70, 16, t60, 16);
    t82 = (t0 + 5288);
    xsi_vlogvar_assign_value(t82, t59, 0, 0, 32);
    goto LAB32;

LAB36:    t14 = (t37 + 4);
    *((unsigned int *)t37) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB37;

LAB38:    xsi_set_current_line(48, ng0);

LAB41:    xsi_set_current_line(49, ng0);
    t28 = (t0 + 2488U);
    t29 = *((char **)t28);
    memset(t59, 0, 8);
    t28 = (t59 + 4);
    t35 = (t29 + 4);
    t40 = *((unsigned int *)t29);
    t41 = (t40 >> 16);
    *((unsigned int *)t59) = t41;
    t42 = *((unsigned int *)t35);
    t43 = (t42 >> 16);
    *((unsigned int *)t28) = t43;
    t44 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t44 & 65535U);
    t45 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t45 & 65535U);
    t36 = ((char*)((ng11)));
    t52 = (t0 + 2488U);
    t53 = *((char **)t52);
    memset(t70, 0, 8);
    t52 = (t70 + 4);
    t61 = (t53 + 4);
    t46 = *((unsigned int *)t53);
    t47 = (t46 >> 31);
    t48 = (t47 & 1);
    *((unsigned int *)t70) = t48;
    t49 = *((unsigned int *)t61);
    t50 = (t49 >> 31);
    t51 = (t50 & 1);
    *((unsigned int *)t52) = t51;
    xsi_vlog_mul_concat(t60, 16, 1, t36, 1U, t70, 1);
    xsi_vlogtype_concat(t39, 32, 32, 2U, t60, 16, t59, 16);
    t62 = (t0 + 5288);
    xsi_vlogvar_assign_value(t62, t39, 0, 0, 32);
    goto LAB40;

LAB44:    t11 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB45;

LAB46:    xsi_set_current_line(51, ng0);

LAB49:    xsi_set_current_line(52, ng0);
    t14 = (t0 + 2648U);
    t15 = *((char **)t14);
    memset(t37, 0, 8);
    t14 = (t37 + 4);
    t28 = (t15 + 4);
    t30 = *((unsigned int *)t15);
    t31 = (t30 >> 0);
    *((unsigned int *)t37) = t31;
    t32 = *((unsigned int *)t28);
    t33 = (t32 >> 0);
    *((unsigned int *)t14) = t33;
    t34 = *((unsigned int *)t37);
    *((unsigned int *)t37) = (t34 & 3U);
    t38 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t38 & 3U);
    t29 = ((char*)((ng10)));
    memset(t39, 0, 8);
    t35 = (t37 + 4);
    t36 = (t29 + 4);
    t40 = *((unsigned int *)t37);
    t41 = *((unsigned int *)t29);
    t42 = (t40 ^ t41);
    t43 = *((unsigned int *)t35);
    t44 = *((unsigned int *)t36);
    t45 = (t43 ^ t44);
    t46 = (t42 | t45);
    t47 = *((unsigned int *)t35);
    t48 = *((unsigned int *)t36);
    t49 = (t47 | t48);
    t50 = (~(t49));
    t51 = (t46 & t50);
    if (t51 != 0)
        goto LAB53;

LAB50:    if (t49 != 0)
        goto LAB52;

LAB51:    *((unsigned int *)t39) = 1;

LAB53:    t53 = (t39 + 4);
    t54 = *((unsigned int *)t53);
    t55 = (~(t54));
    t56 = *((unsigned int *)t39);
    t57 = (t56 & t55);
    t58 = (t57 != 0);
    if (t58 > 0)
        goto LAB54;

LAB55:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 0);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 3U);
    t16 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t16 & 3U);
    t5 = ((char*)((ng14)));
    memset(t37, 0, 8);
    t11 = (t13 + 4);
    t12 = (t5 + 4);
    t17 = *((unsigned int *)t13);
    t18 = *((unsigned int *)t5);
    t19 = (t17 ^ t18);
    t20 = *((unsigned int *)t11);
    t21 = *((unsigned int *)t12);
    t22 = (t20 ^ t21);
    t23 = (t19 | t22);
    t24 = *((unsigned int *)t11);
    t25 = *((unsigned int *)t12);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t30 = (t23 & t27);
    if (t30 != 0)
        goto LAB61;

LAB58:    if (t26 != 0)
        goto LAB60;

LAB59:    *((unsigned int *)t37) = 1;

LAB61:    t15 = (t37 + 4);
    t31 = *((unsigned int *)t15);
    t32 = (~(t31));
    t33 = *((unsigned int *)t37);
    t34 = (t33 & t32);
    t38 = (t34 != 0);
    if (t38 > 0)
        goto LAB62;

LAB63:    xsi_set_current_line(56, ng0);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 0);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 3U);
    t16 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t16 & 3U);
    t5 = ((char*)((ng12)));
    memset(t37, 0, 8);
    t11 = (t13 + 4);
    t12 = (t5 + 4);
    t17 = *((unsigned int *)t13);
    t18 = *((unsigned int *)t5);
    t19 = (t17 ^ t18);
    t20 = *((unsigned int *)t11);
    t21 = *((unsigned int *)t12);
    t22 = (t20 ^ t21);
    t23 = (t19 | t22);
    t24 = *((unsigned int *)t11);
    t25 = *((unsigned int *)t12);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t30 = (t23 & t27);
    if (t30 != 0)
        goto LAB69;

LAB66:    if (t26 != 0)
        goto LAB68;

LAB67:    *((unsigned int *)t37) = 1;

LAB69:    t15 = (t37 + 4);
    t31 = *((unsigned int *)t15);
    t32 = (~(t31));
    t33 = *((unsigned int *)t37);
    t34 = (t33 & t32);
    t38 = (t34 != 0);
    if (t38 > 0)
        goto LAB70;

LAB71:    xsi_set_current_line(58, ng0);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 0);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 3U);
    t16 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t16 & 3U);
    t5 = ((char*)((ng15)));
    memset(t37, 0, 8);
    t11 = (t13 + 4);
    t12 = (t5 + 4);
    t17 = *((unsigned int *)t13);
    t18 = *((unsigned int *)t5);
    t19 = (t17 ^ t18);
    t20 = *((unsigned int *)t11);
    t21 = *((unsigned int *)t12);
    t22 = (t20 ^ t21);
    t23 = (t19 | t22);
    t24 = *((unsigned int *)t11);
    t25 = *((unsigned int *)t12);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t30 = (t23 & t27);
    if (t30 != 0)
        goto LAB77;

LAB74:    if (t26 != 0)
        goto LAB76;

LAB75:    *((unsigned int *)t37) = 1;

LAB77:    t15 = (t37 + 4);
    t31 = *((unsigned int *)t15);
    t32 = (~(t31));
    t33 = *((unsigned int *)t37);
    t34 = (t33 & t32);
    t38 = (t34 != 0);
    if (t38 > 0)
        goto LAB78;

LAB79:
LAB80:
LAB72:
LAB64:
LAB56:    goto LAB48;

LAB52:    t52 = (t39 + 4);
    *((unsigned int *)t39) = 1;
    *((unsigned int *)t52) = 1;
    goto LAB53;

LAB54:    xsi_set_current_line(52, ng0);

LAB57:    xsi_set_current_line(53, ng0);
    t61 = (t0 + 2488U);
    t62 = *((char **)t61);
    memset(t60, 0, 8);
    t61 = (t60 + 4);
    t63 = (t62 + 4);
    t64 = *((unsigned int *)t62);
    t65 = (t64 >> 0);
    *((unsigned int *)t60) = t65;
    t66 = *((unsigned int *)t63);
    t67 = (t66 >> 0);
    *((unsigned int *)t61) = t67;
    t68 = *((unsigned int *)t60);
    *((unsigned int *)t60) = (t68 & 255U);
    t69 = *((unsigned int *)t61);
    *((unsigned int *)t61) = (t69 & 255U);
    t71 = ((char*)((ng13)));
    t72 = (t0 + 2488U);
    t73 = *((char **)t72);
    memset(t74, 0, 8);
    t72 = (t74 + 4);
    t75 = (t73 + 4);
    t76 = *((unsigned int *)t73);
    t77 = (t76 >> 7);
    t78 = (t77 & 1);
    *((unsigned int *)t74) = t78;
    t79 = *((unsigned int *)t75);
    t80 = (t79 >> 7);
    t81 = (t80 & 1);
    *((unsigned int *)t72) = t81;
    xsi_vlog_mul_concat(t70, 24, 1, t71, 1U, t74, 1);
    xsi_vlogtype_concat(t59, 32, 32, 2U, t70, 24, t60, 8);
    t82 = (t0 + 5288);
    xsi_vlogvar_assign_value(t82, t59, 0, 0, 32);
    goto LAB56;

LAB60:    t14 = (t37 + 4);
    *((unsigned int *)t37) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB61;

LAB62:    xsi_set_current_line(54, ng0);

LAB65:    xsi_set_current_line(55, ng0);
    t28 = (t0 + 2488U);
    t29 = *((char **)t28);
    memset(t59, 0, 8);
    t28 = (t59 + 4);
    t35 = (t29 + 4);
    t40 = *((unsigned int *)t29);
    t41 = (t40 >> 8);
    *((unsigned int *)t59) = t41;
    t42 = *((unsigned int *)t35);
    t43 = (t42 >> 8);
    *((unsigned int *)t28) = t43;
    t44 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t44 & 255U);
    t45 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t45 & 255U);
    t36 = ((char*)((ng13)));
    t52 = (t0 + 2488U);
    t53 = *((char **)t52);
    memset(t70, 0, 8);
    t52 = (t70 + 4);
    t61 = (t53 + 4);
    t46 = *((unsigned int *)t53);
    t47 = (t46 >> 15);
    t48 = (t47 & 1);
    *((unsigned int *)t70) = t48;
    t49 = *((unsigned int *)t61);
    t50 = (t49 >> 15);
    t51 = (t50 & 1);
    *((unsigned int *)t52) = t51;
    xsi_vlog_mul_concat(t60, 24, 1, t36, 1U, t70, 1);
    xsi_vlogtype_concat(t39, 32, 32, 2U, t60, 24, t59, 8);
    t62 = (t0 + 5288);
    xsi_vlogvar_assign_value(t62, t39, 0, 0, 32);
    goto LAB64;

LAB68:    t14 = (t37 + 4);
    *((unsigned int *)t37) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB69;

LAB70:    xsi_set_current_line(56, ng0);

LAB73:    xsi_set_current_line(57, ng0);
    t28 = (t0 + 2488U);
    t29 = *((char **)t28);
    memset(t59, 0, 8);
    t28 = (t59 + 4);
    t35 = (t29 + 4);
    t40 = *((unsigned int *)t29);
    t41 = (t40 >> 16);
    *((unsigned int *)t59) = t41;
    t42 = *((unsigned int *)t35);
    t43 = (t42 >> 16);
    *((unsigned int *)t28) = t43;
    t44 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t44 & 255U);
    t45 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t45 & 255U);
    t36 = ((char*)((ng13)));
    t52 = (t0 + 2488U);
    t53 = *((char **)t52);
    memset(t70, 0, 8);
    t52 = (t70 + 4);
    t61 = (t53 + 4);
    t46 = *((unsigned int *)t53);
    t47 = (t46 >> 23);
    t48 = (t47 & 1);
    *((unsigned int *)t70) = t48;
    t49 = *((unsigned int *)t61);
    t50 = (t49 >> 23);
    t51 = (t50 & 1);
    *((unsigned int *)t52) = t51;
    xsi_vlog_mul_concat(t60, 24, 1, t36, 1U, t70, 1);
    xsi_vlogtype_concat(t39, 32, 32, 2U, t60, 24, t59, 8);
    t62 = (t0 + 5288);
    xsi_vlogvar_assign_value(t62, t39, 0, 0, 32);
    goto LAB72;

LAB76:    t14 = (t37 + 4);
    *((unsigned int *)t37) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB77;

LAB78:    xsi_set_current_line(58, ng0);

LAB81:    xsi_set_current_line(59, ng0);
    t28 = (t0 + 2488U);
    t29 = *((char **)t28);
    memset(t59, 0, 8);
    t28 = (t59 + 4);
    t35 = (t29 + 4);
    t40 = *((unsigned int *)t29);
    t41 = (t40 >> 24);
    *((unsigned int *)t59) = t41;
    t42 = *((unsigned int *)t35);
    t43 = (t42 >> 24);
    *((unsigned int *)t28) = t43;
    t44 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t44 & 255U);
    t45 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t45 & 255U);
    t36 = ((char*)((ng13)));
    t52 = (t0 + 2488U);
    t53 = *((char **)t52);
    memset(t70, 0, 8);
    t52 = (t70 + 4);
    t61 = (t53 + 4);
    t46 = *((unsigned int *)t53);
    t47 = (t46 >> 31);
    t48 = (t47 & 1);
    *((unsigned int *)t70) = t48;
    t49 = *((unsigned int *)t61);
    t50 = (t49 >> 31);
    t51 = (t50 & 1);
    *((unsigned int *)t52) = t51;
    xsi_vlog_mul_concat(t60, 24, 1, t36, 1U, t70, 1);
    xsi_vlogtype_concat(t39, 32, 32, 2U, t60, 24, t59, 8);
    t62 = (t0 + 5288);
    xsi_vlogvar_assign_value(t62, t39, 0, 0, 32);
    goto LAB80;

}

static void Always_65_8(char *t0)
{
    char t13[8];
    char t35[8];
    char t37[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    unsigned int t36;
    char *t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    char *t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t59;
    char *t60;

LAB0:    t1 = (t0 + 8344U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(65, ng0);
    t2 = (t0 + 8776);
    *((int *)t2) = 1;
    t3 = (t0 + 8376);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(65, ng0);

LAB5:    xsi_set_current_line(66, ng0);
    t4 = (t0 + 3448U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2808U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(98, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);

LAB12:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(66, ng0);

LAB9:    xsi_set_current_line(67, ng0);
    t11 = ((char*)((ng16)));
    t12 = (t0 + 5448);
    xsi_vlogvar_assign_value(t12, t11, 0, 0, 4);
    xsi_set_current_line(68, ng0);
    t2 = (t0 + 1528U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng7)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_add(t13, 32, t3, 32, t2, 32);
    t4 = (t0 + 5128);
    xsi_vlogvar_assign_value(t4, t13, 0, 0, 32);
    goto LAB8;

LAB10:    xsi_set_current_line(70, ng0);

LAB13:    xsi_set_current_line(71, ng0);
    t4 = (t0 + 4728U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng3)));
    memset(t13, 0, 8);
    t11 = (t5 + 4);
    t12 = (t4 + 4);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t4);
    t16 = (t14 ^ t15);
    t17 = *((unsigned int *)t11);
    t18 = *((unsigned int *)t12);
    t19 = (t17 ^ t18);
    t20 = (t16 | t19);
    t21 = *((unsigned int *)t11);
    t22 = *((unsigned int *)t12);
    t23 = (t21 | t22);
    t24 = (~(t23));
    t25 = (t20 & t24);
    if (t25 != 0)
        goto LAB17;

LAB14:    if (t23 != 0)
        goto LAB16;

LAB15:    *((unsigned int *)t13) = 1;

LAB17:    t27 = (t13 + 4);
    t28 = *((unsigned int *)t27);
    t29 = (~(t28));
    t30 = *((unsigned int *)t13);
    t31 = (t30 & t29);
    t32 = (t31 != 0);
    if (t32 > 0)
        goto LAB18;

LAB19:    xsi_set_current_line(74, ng0);
    t2 = (t0 + 4728U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng4)));
    memset(t13, 0, 8);
    t4 = (t3 + 4);
    t5 = (t2 + 4);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t2);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t14 = (t9 ^ t10);
    t15 = (t8 | t14);
    t16 = *((unsigned int *)t4);
    t17 = *((unsigned int *)t5);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB25;

LAB22:    if (t18 != 0)
        goto LAB24;

LAB23:    *((unsigned int *)t13) = 1;

LAB25:    t12 = (t13 + 4);
    t21 = *((unsigned int *)t12);
    t22 = (~(t21));
    t23 = *((unsigned int *)t13);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB26;

LAB27:    xsi_set_current_line(83, ng0);
    t2 = (t0 + 4728U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng6)));
    memset(t13, 0, 8);
    t4 = (t3 + 4);
    t5 = (t2 + 4);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t2);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t14 = (t9 ^ t10);
    t15 = (t8 | t14);
    t16 = *((unsigned int *)t4);
    t17 = *((unsigned int *)t5);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB49;

LAB46:    if (t18 != 0)
        goto LAB48;

LAB47:    *((unsigned int *)t13) = 1;

LAB49:    t12 = (t13 + 4);
    t21 = *((unsigned int *)t12);
    t22 = (~(t21));
    t23 = *((unsigned int *)t13);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB50;

LAB51:    xsi_set_current_line(97, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);

LAB52:
LAB28:
LAB20:    goto LAB12;

LAB16:    t26 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t26) = 1;
    goto LAB17;

LAB18:    xsi_set_current_line(71, ng0);

LAB21:    xsi_set_current_line(72, ng0);
    t33 = ((char*)((ng16)));
    t34 = (t0 + 5448);
    xsi_vlogvar_assign_value(t34, t33, 0, 0, 4);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = (t0 + 5128);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 32);
    goto LAB20;

LAB24:    t11 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB25;

LAB26:    xsi_set_current_line(74, ng0);

LAB29:    xsi_set_current_line(75, ng0);
    t26 = (t0 + 2648U);
    t27 = *((char **)t26);
    memset(t35, 0, 8);
    t26 = (t35 + 4);
    t33 = (t27 + 4);
    t28 = *((unsigned int *)t27);
    t29 = (t28 >> 0);
    *((unsigned int *)t35) = t29;
    t30 = *((unsigned int *)t33);
    t31 = (t30 >> 0);
    *((unsigned int *)t26) = t31;
    t32 = *((unsigned int *)t35);
    *((unsigned int *)t35) = (t32 & 3U);
    t36 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t36 & 3U);
    t34 = ((char*)((ng10)));
    memset(t37, 0, 8);
    t38 = (t35 + 4);
    t39 = (t34 + 4);
    t40 = *((unsigned int *)t35);
    t41 = *((unsigned int *)t34);
    t42 = (t40 ^ t41);
    t43 = *((unsigned int *)t38);
    t44 = *((unsigned int *)t39);
    t45 = (t43 ^ t44);
    t46 = (t42 | t45);
    t47 = *((unsigned int *)t38);
    t48 = *((unsigned int *)t39);
    t49 = (t47 | t48);
    t50 = (~(t49));
    t51 = (t46 & t50);
    if (t51 != 0)
        goto LAB33;

LAB30:    if (t49 != 0)
        goto LAB32;

LAB31:    *((unsigned int *)t37) = 1;

LAB33:    t53 = (t37 + 4);
    t54 = *((unsigned int *)t53);
    t55 = (~(t54));
    t56 = *((unsigned int *)t37);
    t57 = (t56 & t55);
    t58 = (t57 != 0);
    if (t58 > 0)
        goto LAB34;

LAB35:    xsi_set_current_line(78, ng0);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 0);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 3U);
    t14 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t14 & 3U);
    t5 = ((char*)((ng12)));
    memset(t35, 0, 8);
    t11 = (t13 + 4);
    t12 = (t5 + 4);
    t15 = *((unsigned int *)t13);
    t16 = *((unsigned int *)t5);
    t17 = (t15 ^ t16);
    t18 = *((unsigned int *)t11);
    t19 = *((unsigned int *)t12);
    t20 = (t18 ^ t19);
    t21 = (t17 | t20);
    t22 = *((unsigned int *)t11);
    t23 = *((unsigned int *)t12);
    t24 = (t22 | t23);
    t25 = (~(t24));
    t28 = (t21 & t25);
    if (t28 != 0)
        goto LAB41;

LAB38:    if (t24 != 0)
        goto LAB40;

LAB39:    *((unsigned int *)t35) = 1;

LAB41:    t27 = (t35 + 4);
    t29 = *((unsigned int *)t27);
    t30 = (~(t29));
    t31 = *((unsigned int *)t35);
    t32 = (t31 & t30);
    t36 = (t32 != 0);
    if (t36 > 0)
        goto LAB42;

LAB43:    xsi_set_current_line(82, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);

LAB44:
LAB36:    goto LAB28;

LAB32:    t52 = (t37 + 4);
    *((unsigned int *)t37) = 1;
    *((unsigned int *)t52) = 1;
    goto LAB33;

LAB34:    xsi_set_current_line(75, ng0);

LAB37:    xsi_set_current_line(76, ng0);
    t59 = ((char*)((ng15)));
    t60 = (t0 + 5448);
    xsi_vlogvar_assign_value(t60, t59, 0, 0, 4);
    xsi_set_current_line(77, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = (t0 + 5128);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 32);
    goto LAB36;

LAB40:    t26 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t26) = 1;
    goto LAB41;

LAB42:    xsi_set_current_line(78, ng0);

LAB45:    xsi_set_current_line(79, ng0);
    t33 = ((char*)((ng17)));
    t34 = (t0 + 5448);
    xsi_vlogvar_assign_value(t34, t33, 0, 0, 4);
    xsi_set_current_line(80, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng11)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_lshift(t13, 32, t3, 32, t2, 32);
    t4 = (t0 + 5128);
    xsi_vlogvar_assign_value(t4, t13, 0, 0, 32);
    goto LAB44;

LAB48:    t11 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB49;

LAB50:    xsi_set_current_line(83, ng0);

LAB53:    xsi_set_current_line(84, ng0);
    t26 = (t0 + 2648U);
    t27 = *((char **)t26);
    memset(t35, 0, 8);
    t26 = (t35 + 4);
    t33 = (t27 + 4);
    t28 = *((unsigned int *)t27);
    t29 = (t28 >> 0);
    *((unsigned int *)t35) = t29;
    t30 = *((unsigned int *)t33);
    t31 = (t30 >> 0);
    *((unsigned int *)t26) = t31;
    t32 = *((unsigned int *)t35);
    *((unsigned int *)t35) = (t32 & 3U);
    t36 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t36 & 3U);
    t34 = ((char*)((ng10)));
    memset(t37, 0, 8);
    t38 = (t35 + 4);
    t39 = (t34 + 4);
    t40 = *((unsigned int *)t35);
    t41 = *((unsigned int *)t34);
    t42 = (t40 ^ t41);
    t43 = *((unsigned int *)t38);
    t44 = *((unsigned int *)t39);
    t45 = (t43 ^ t44);
    t46 = (t42 | t45);
    t47 = *((unsigned int *)t38);
    t48 = *((unsigned int *)t39);
    t49 = (t47 | t48);
    t50 = (~(t49));
    t51 = (t46 & t50);
    if (t51 != 0)
        goto LAB57;

LAB54:    if (t49 != 0)
        goto LAB56;

LAB55:    *((unsigned int *)t37) = 1;

LAB57:    t53 = (t37 + 4);
    t54 = *((unsigned int *)t53);
    t55 = (~(t54));
    t56 = *((unsigned int *)t37);
    t57 = (t56 & t55);
    t58 = (t57 != 0);
    if (t58 > 0)
        goto LAB58;

LAB59:    xsi_set_current_line(87, ng0);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 0);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 3U);
    t14 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t14 & 3U);
    t5 = ((char*)((ng14)));
    memset(t35, 0, 8);
    t11 = (t13 + 4);
    t12 = (t5 + 4);
    t15 = *((unsigned int *)t13);
    t16 = *((unsigned int *)t5);
    t17 = (t15 ^ t16);
    t18 = *((unsigned int *)t11);
    t19 = *((unsigned int *)t12);
    t20 = (t18 ^ t19);
    t21 = (t17 | t20);
    t22 = *((unsigned int *)t11);
    t23 = *((unsigned int *)t12);
    t24 = (t22 | t23);
    t25 = (~(t24));
    t28 = (t21 & t25);
    if (t28 != 0)
        goto LAB65;

LAB62:    if (t24 != 0)
        goto LAB64;

LAB63:    *((unsigned int *)t35) = 1;

LAB65:    t27 = (t35 + 4);
    t29 = *((unsigned int *)t27);
    t30 = (~(t29));
    t31 = *((unsigned int *)t35);
    t32 = (t31 & t30);
    t36 = (t32 != 0);
    if (t36 > 0)
        goto LAB66;

LAB67:    xsi_set_current_line(90, ng0);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 0);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 3U);
    t14 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t14 & 3U);
    t5 = ((char*)((ng12)));
    memset(t35, 0, 8);
    t11 = (t13 + 4);
    t12 = (t5 + 4);
    t15 = *((unsigned int *)t13);
    t16 = *((unsigned int *)t5);
    t17 = (t15 ^ t16);
    t18 = *((unsigned int *)t11);
    t19 = *((unsigned int *)t12);
    t20 = (t18 ^ t19);
    t21 = (t17 | t20);
    t22 = *((unsigned int *)t11);
    t23 = *((unsigned int *)t12);
    t24 = (t22 | t23);
    t25 = (~(t24));
    t28 = (t21 & t25);
    if (t28 != 0)
        goto LAB73;

LAB70:    if (t24 != 0)
        goto LAB72;

LAB71:    *((unsigned int *)t35) = 1;

LAB73:    t27 = (t35 + 4);
    t29 = *((unsigned int *)t27);
    t30 = (~(t29));
    t31 = *((unsigned int *)t35);
    t32 = (t31 & t30);
    t36 = (t32 != 0);
    if (t36 > 0)
        goto LAB74;

LAB75:    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 0);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 3U);
    t14 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t14 & 3U);
    t5 = ((char*)((ng15)));
    memset(t35, 0, 8);
    t11 = (t13 + 4);
    t12 = (t5 + 4);
    t15 = *((unsigned int *)t13);
    t16 = *((unsigned int *)t5);
    t17 = (t15 ^ t16);
    t18 = *((unsigned int *)t11);
    t19 = *((unsigned int *)t12);
    t20 = (t18 ^ t19);
    t21 = (t17 | t20);
    t22 = *((unsigned int *)t11);
    t23 = *((unsigned int *)t12);
    t24 = (t22 | t23);
    t25 = (~(t24));
    t28 = (t21 & t25);
    if (t28 != 0)
        goto LAB81;

LAB78:    if (t24 != 0)
        goto LAB80;

LAB79:    *((unsigned int *)t35) = 1;

LAB81:    t27 = (t35 + 4);
    t29 = *((unsigned int *)t27);
    t30 = (~(t29));
    t31 = *((unsigned int *)t35);
    t32 = (t31 & t30);
    t36 = (t32 != 0);
    if (t36 > 0)
        goto LAB82;

LAB83:    xsi_set_current_line(96, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);

LAB84:
LAB76:
LAB68:
LAB60:    goto LAB52;

LAB56:    t52 = (t37 + 4);
    *((unsigned int *)t37) = 1;
    *((unsigned int *)t52) = 1;
    goto LAB57;

LAB58:    xsi_set_current_line(84, ng0);

LAB61:    xsi_set_current_line(85, ng0);
    t59 = ((char*)((ng14)));
    t60 = (t0 + 5448);
    xsi_vlogvar_assign_value(t60, t59, 0, 0, 4);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = (t0 + 5128);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 32);
    goto LAB60;

LAB64:    t26 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t26) = 1;
    goto LAB65;

LAB66:    xsi_set_current_line(87, ng0);

LAB69:    xsi_set_current_line(88, ng0);
    t33 = ((char*)((ng12)));
    t34 = (t0 + 5448);
    xsi_vlogvar_assign_value(t34, t33, 0, 0, 4);
    xsi_set_current_line(89, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng7)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_lshift(t13, 32, t3, 32, t2, 32);
    t4 = (t0 + 5128);
    xsi_vlogvar_assign_value(t4, t13, 0, 0, 32);
    goto LAB68;

LAB72:    t26 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t26) = 1;
    goto LAB73;

LAB74:    xsi_set_current_line(90, ng0);

LAB77:    xsi_set_current_line(91, ng0);
    t33 = ((char*)((ng18)));
    t34 = (t0 + 5448);
    xsi_vlogvar_assign_value(t34, t33, 0, 0, 4);
    xsi_set_current_line(92, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng11)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_lshift(t13, 32, t3, 32, t2, 32);
    t4 = (t0 + 5128);
    xsi_vlogvar_assign_value(t4, t13, 0, 0, 32);
    goto LAB76;

LAB80:    t26 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t26) = 1;
    goto LAB81;

LAB82:    xsi_set_current_line(93, ng0);

LAB85:    xsi_set_current_line(94, ng0);
    t33 = ((char*)((ng19)));
    t34 = (t0 + 5448);
    xsi_vlogvar_assign_value(t34, t33, 0, 0, 4);
    xsi_set_current_line(95, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng13)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_lshift(t13, 32, t3, 32, t2, 32);
    t4 = (t0 + 5128);
    xsi_vlogvar_assign_value(t4, t13, 0, 0, 32);
    goto LAB84;

}


extern void work_m_15177427584725673792_2321183677_init()
{
	static char *pe[] = {(void *)Cont_12_0,(void *)NetDecl_15_1,(void *)NetDecl_15_2,(void *)NetDecl_15_3,(void *)Cont_21_4,(void *)Cont_27_5,(void *)Initial_35_6,(void *)Always_41_7,(void *)Always_65_8};
	xsi_register_didat("work_m_15177427584725673792_2321183677", "isim/mips_tbo_isim_beh.exe.sim/work/m_15177427584725673792_2321183677.didat");
	xsi_register_executes(pe);
}
